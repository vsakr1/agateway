package com.test.ci.automation.or.non_network;

public class InventoryValuationScreen {

	public static final String INVENTORYVALUATIONREPORT = "linktext=Inventory Valuation Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSOURCE = "xpath =//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath =//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CommercialType = "xpath =//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO ="xpath = //span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATECARD =	"xpath = //span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SPOTDATA = "";
	public static final String COMMERCIALTYPEGROUP = "xpath =//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FORMATTING = "";
	public static final String DAYPARTDISPLAY ="xpath = //span[text()='Daypart Display']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String AVAILSMEASURE ="xpath = //span[text()='Avails Measure']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYGROUPBY ="xpath = //span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYSORTBY ="xpath = //span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REVISION ="xpath = //span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";
}
