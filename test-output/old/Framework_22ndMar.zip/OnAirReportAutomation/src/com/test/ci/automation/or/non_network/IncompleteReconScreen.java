package com.test.ci.automation.or.non_network;

public class IncompleteReconScreen {
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
}
