package com.test.ci.automation.reports.non_network;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.AdvertiserDistributionbySellingNameScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class AdvertiserDistributionbySellingNameReport  extends BaseScripts {

	public static void main(String[] args) throws InterruptedException, IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		String[] tabs={"General","Plan Data","Spot Data","Selling Name","Formatting"};
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {


			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber,"RunMode", i).equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("No")) 
				{
				} 
				else 
				{
					try {
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());
						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Advertiser Distribution by Selling Name Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Advertiser Distribution by Selling Name Report"))));
						driver.findElement(By.linkText("Advertiser Distribution by Selling Name Report")).click();
						System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
						Thread.sleep(2000);

						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						actionDriver(Link, AdvertiserDistributionbySellingNameScreen.CLEARFORM, "Click", "Clear Form", "Landing Page");


						// General tab
						driver.findElement(By.linkText(""+tabs[0]+"")).click();		
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i))))
							Log.error("Property is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "property", i) );

						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i));
						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i))))
							Log.error("Start Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i) );

						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i));
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i))))
							Log.error("End Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i) );

						//Clicking the "Plan Data" Tab
						driver.findElement(By.linkText(""+tabs[1]+"")).click();	
						//Wait for the page to load
						Thread.sleep(3000);
						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber, "planclass", i),"Plan Class");

						//Clicking the "Spot Data" Tab
						driver.findElement(By.linkText(""+tabs[2]+"")).click();	
						Thread.sleep(4000);
						driver.findElement(By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "commercialtypegroup", i));
						Thread.sleep(4000);
						driver.findElement(By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(4000);
						if(!(driver.findElement(By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "commercialtypegroup", i))))
							Log.error("Commercial Type Group is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "commercialtypegroup", i) );

						//Clicking the "Selling Name" Tab
						driver.findElement(By.linkText(""+tabs[3]+"")).click();	
						//Wait for the page to load
						//waitWhileLoading(driver);
						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber, "daypart", i),"Daypart");	

						//Clicking the "Formatting" Tab
						driver.findElement(By.linkText(""+tabs[4]+"")).click();	

						clickOnFilterCriteriaCheckBox();	
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
							Log.error("Filter Criteria checkbox is not checked");
						exportReport("Formatted Excel");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}