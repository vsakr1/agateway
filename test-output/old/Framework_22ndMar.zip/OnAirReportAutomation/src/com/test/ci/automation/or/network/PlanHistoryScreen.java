package com.test.ci.automation.or.network;

public class PlanHistoryScreen {
	public static final String PLANHISTORYREPORT = "linkText=Plan History Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String SEARCHPLANS = "id=searchcombo_planHistory";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
