package com.test.ci.automation.reports.non_network;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class InventoryValuationReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException,
			IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		// Tab names which come across in the work flow
		String[] tabs = { "General", "Ratecard", "Spot Data", "Selling Name",
				"Formatting" };

		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {
			// launchApplication(config.get("DEBUG"));
			// waitForWindowTitle("Dashboard");
			// WebDriverWait wait = new WebDriverWait(driver, 60);
			// wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Inventory Valuation Report"))));
			// wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Inventory Valuation Report"))));
			// driver.findElement(By.linkText("Inventory Valuation Report")).click();
			// System.out.println(((org.openqa.selenium.JavascriptExecutor)
			// driver).executeScript("return document.readyState"));
			// Thread.sleep(2000);

			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config
					.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i)
						.equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber,
								"RunMode", i).equalsIgnoreCase("No")) {
				} else {
					try {
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());

						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
								.linkText("Inventory Valuation Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.linkText("Inventory Valuation Report"))));
						driver.findElement(
								By.linkText("Inventory Valuation Report"))
								.click();
						System.out
								.println(((org.openqa.selenium.JavascriptExecutor) driver)
										.executeScript("return document.readyState"));
						Thread.sleep(2000);
						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//button[text()='Clear Form']"))));
						driver.findElement(
								By.xpath("//button[text()='Clear Form']"))
								.click();
						Thread.sleep(3000);

						// General tab
						driver.findElement(By.linkText("" + tabs[0] + ""))
								.click();
						driver.findElement(
								By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "property", i));
						driver.findElement(
								By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "property", i))))
							Log.error("Property is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "property", i));

						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "startdate", i));
						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "startdate", i))))
							Log.error("Start Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "startdate", i));

						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "enddate", i));
						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "enddate", i))))
							Log.error("End Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "enddate", i));

						// Ratecard Tab
						// driver.findElement(By.linkText(""+tabs[1]+"")).click();
						// Thread.sleep(3000);
						// driver.findElement(By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingsource", i));
						// driver.findElement(By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						// Thread.sleep(3000);
						// if(!(driver.findElement(By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingsource", i))))
						// Log.error("Rating Source is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingsource", i) );
						//
						//
						//
						// driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "demo", i));
						// driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						// Thread.sleep(3000);
						// if(!(driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "demo", i))))
						// Log.error("Demo is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "demo", i) );
						//
						//
						// if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
						// Log.error("Filter Criteria checkbox is not checked");
						//
						driver.findElement(By.linkText("" + tabs[1] + ""))
								.click();
						Thread.sleep(3000);
						driver.findElement(
								By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "ratingsource", i));
						driver.findElement(
								By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Rating Source']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "ratingsource", i))))
							Log.error("Rating Source is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "ratingsource", i));

						driver.findElement(
								By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "ratingstream", i));
						driver.findElement(
								By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "ratingstream", i))))
							Log.error("Rating Stream is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "ratingstream", i));

						driver.findElement(
								By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "commercialtype",
												i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "commercialtype", i))))
							Log.error("Commercial Type is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "commercialtype", i));

						driver.findElement(
								By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "ratecard", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "ratecard", i))))
							Log.error("Demo is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "demo", i));
						System.out.println(ReadWriteTestDataSheet.excelText(
								sheetNumber, "revision", i)
								+ "  this is the value");
						driver.findElement(
								By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "revision", i));
						driver.findElement(
								By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "revision", i))))
							Log.error("Revision is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "revision", i));

						driver.findElement(
								By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "demo", i));
						driver.findElement(
								By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "demo", i))))
							Log.error("Demo is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "demo", i));

						//
						// if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
						// Log.error("Filter Criteria checkbox is not checked");
						//
						// //Work Around
						// //Ratecard Tab
						// driver.findElement(By.linkText(""+tabs[1]+"")).click();
						// Thread.sleep(5000);

						// Spot Data tab
						driver.findElement(By.linkText("" + tabs[2] + ""))
								.click();
						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber,
												"commercialtypegroup", i));
						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "commercialtypegroup", i))))
							Log.error("Commercial Type Group is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "commercialtypegroup",
											i));

						// Clicking the "Selling Name" Tab
						driver.findElement(By.linkText("" + tabs[3] + ""))
								.click();
						Thread.sleep(2000);
						Application_Utils.moveToRight(driver,
								ReadWriteTestDataSheet.excelText(sheetNumber,
										"daypart", i), "Daypart");

						// Formatting tab
						driver.findElement(By.linkText("" + tabs[4] + ""))
								.click();
						driver.findElement(
								By.xpath("//span[text()='Daypart Display']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartdisplay",
												i));
						driver.findElement(
								By.xpath("//span[text()='Daypart Display']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Daypart Display']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "daypartdisplay", i))))
							Log.error("Daypart Display is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "daypartdisplay", i));

						driver.findElement(
								By.xpath("//span[text()='Avails Measure']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet
												.excelText(sheetNumber,
														"availsmeasure", i));
						driver.findElement(
								By.xpath("//span[text()='Avails Measure']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Avails Measure']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "availsmeasure", i))))
							Log.error("Avails Measure Display is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "availsmeasure", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Include Reserves']/following::a[contains(@class,'xcheckbox-off')]"))
								.click();
						Thread.sleep(1000);
						if (!driver
								.findElement(
										By.xpath("//span[text()='Include Reserves']/following::a[contains(@class,'xcheckbox')]"))
								.getAttribute("class")
								.contains(" xcheckbox-on"))
							Log.error("Include Reserves checkbox is not checked");
						Thread.sleep(2000);
						driver.findElement(
								By.xpath("//span[text()='Include 0 Avails']/following::a[contains(@class,'xcheckbox-off')]"))
								.click();
						Thread.sleep(1000);
						if (!driver
								.findElement(
										By.xpath("//span[text()='Include 0 Avails']/following::a[contains(@class,'xcheckbox')]"))
								.getAttribute("class")
								.contains(" xcheckbox-on"))
							Log.error("Include 0 Avails checkbox is not checked");
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "primarygroupby",
												i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "primarygroupby", i))))
							Log.error("Primary Group By  is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "primarygroupby", i));

						driver.findElement(
								By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet
												.excelText(sheetNumber,
														"primarysortby", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "primarysortby", i))))
							Log.error("Primary Sort By  is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "primarysortby", i));

						if (ReadWriteTestDataSheet.excelText(sheetNumber,
								"primarygroupby", i).equals("Daypart")) {
							driver.findElement(
									By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.sendKeys(
											ReadWriteTestDataSheet.excelText(
													sheetNumber,
													"daypartsummary", i));
							driver.findElement(
									By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.sendKeys(Keys.ENTER);
							Thread.sleep(1000);
							if (!(driver
									.findElement(
											By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.getAttribute("value")
									.equals(ReadWriteTestDataSheet.excelText(
											sheetNumber, "daypartsummary", i))))
								Log.error("Daypart Summary  is not "
										+ ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartsummary",
												i));
						}

						clickOnFilterCriteriaCheckBox();
						Thread.sleep(5000);
						// if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
						// Log.error("Filter Criteria checkbox is not checked");
						//
						// //Work Around
						// //Ratecard Tab
						// driver.findElement(By.linkText(""+tabs[1]+"")).click();
						// Thread.sleep(5000);
						//
						// driver.findElement(By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "commercialtype", i));
						// Thread.sleep(5000);
						// driver.findElement(By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						// Thread.sleep(5000);
						// if(!(driver.findElement(By.xpath("//span[text()='Commercial Type']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "commercialtype", i))))
						// Log.error("Commercial Type is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "commercialtype", i) );
						//
						// driver.findElement(By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingstream", i));
						// driver.findElement(By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						// Thread.sleep(3000);
						// if(!(driver.findElement(By.xpath("//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingstream", i))))
						// Log.error("Rating Stream is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratingstream", i) );
						//
						// driver.findElement(By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratecard", i));
						// Thread.sleep(3000);
						// driver.findElement(By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						// if(!(driver.findElement(By.xpath("//span[@class='field_label' and text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "ratecard", i))))
						// Log.error("Demo is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "demo", i) );
						//
						// driver.findElement(By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "revision", i));
						// driver.findElement(By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.TAB);
						// Thread.sleep(4000);
						// if(!(driver.findElement(By.xpath("//span[text()='Revision']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber,
						// "revision", i))))
						// Log.error("Revision is not "+ReadWriteTestDataSheet.excelText(sheetNumber,
						// "revision", i) );
						//
						//
						exportReport("Formatted Excel");
						Thread.sleep(2000);
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""
								+ sheetName
								+ "\" report for iteration "
								+ i
								+ " is "
								+ Formatter.getTimeLapsed(startTimeIs,
										endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close"))
								.click();
						// driver.close();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			exreport.endTest(exlogger);
		}

		exreport.flush();
	}
}