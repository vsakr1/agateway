package com.test.ci.automation.reports.non_network;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.ProposalScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class Proposal_Report extends BaseScripts {

	public static void main(String[] args) throws InterruptedException,
			IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		// Assigning the environment
		String[] tabs = { "General", "Formatting" };

		// Application_Utils.setSettingsFileNamePath(settingsFileName);
		// Application_Utils.setReportName(sheetName);
		/**
		 * new code
		 */
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {
			// launch application
			launchApplicationByEnvironment(config.get("ENV"));

			System.out.println(driver.findElement(By.cssSelector("div.x-tip"))
					.getText()
					+ " this is the text after we launch application");
			// wait for the title
			waitForWindowTitle("Dashboard");
			Thread.sleep(10000);
			System.out.println(driver.getCurrentUrl());
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Proposal Report"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Proposal Report"))));
			driver.findElement(By.linkText("Proposal Report")).click();
			System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
			Thread.sleep(2000);

			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {
				try {
					if (ReadWriteTestDataSheet.excelText(sheetNumber,"RunMode", i).equalsIgnoreCase("N")
							|| ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("No")) 
					{
					} 
					else 
					{
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();

				/*		// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						Thread.sleep(4000);
						actionDriver(Link, ProposalScreen.CLEARFORM, "Click", "Clear Form", "Landing Page");*/
						
						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//button[text()='Clear Form']"))));
						driver.findElement(By.xpath("//button[text()='Clear Form']")).click();
						Thread.sleep(3000);
						

						driver.findElement(By.xpath("//input[@id='searchcombo' and contains(@class,'x-form-text x-form-field')]")).clear();
						driver.findElement(By.xpath("//input[@id='searchcombo' and contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "plannumber", i));
						//Application_Utils.waitWhileLoading(driver);
						Thread.sleep(3000);
						driver.findElement(By.xpath("//input[@id='searchcombo' and contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(3000);
						driver.findElement(By.xpath("//input[@id='adminHistoryButton' and contains(@class,'x-form-text x-form-field')]")).click();
						Thread.sleep(3000);
						driver.findElement(By.xpath("//div[contains(@class,'x-combo-list-item') and text()='"+ReadWriteTestDataSheet.excelText(sheetNumber, "template", i)+"']")).click();
						Thread.sleep(3000);


						driver.findElement(By.xpath("//button[text()='Next']")).click();
						Application_Utils.waitWhileLoading(driver);
						exportReport("PDF");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			driver.close();
			driver.quit();
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}