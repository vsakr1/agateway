package com.test.ci.automation.scripts;

public class RunComparision extends BaseScripts{

}
