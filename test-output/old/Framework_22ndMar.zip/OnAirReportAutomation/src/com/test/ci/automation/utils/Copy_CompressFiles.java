package com.test.ci.automation.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;

public class Copy_CompressFiles 
{
	public static void main(String[] args) 
	{	
		try{
			//Path were the execution results are stored
			String inputPath ="////C://Users//206423258//Desktop//MondayTest//743";
			String backupPath="////USAOANVNP014//ci_archive//Automation//Comparision//Prod";

			DateFormat dateFormat = new SimpleDateFormat("ddMMMyyyy_HH_mm");
			Date date = new Date();

			String networtReports[]={"ADVERTISERLOG", "AIRINGPOSITION", "CHUCK", "CUTBACK", "DEMORATINGSCOMPARE", "COMMERCIALFORMATREPORTUNITVALUE",
					"PROGRAMLINEUP", "TRANSACTIONS", "FINANCEQUARTERLYSUMMARY", "CUTBACK",
					"COMMERCIALPOSITION", "NETWORKSALES", "NOCHARGE", "SALESANALYSIS", "RUNOFSCHEDULE",
					"REVISIONHISTORY", "PROMORATING", "PLANHISTORY", "PROGRAMINVENTORY",
					"PLANDETAIL", "PROGRAMHISTORY", "COMMERCIALFORMAT", "VALUEOFADURCPS"};

			String non_networtReports[]={"ADSALESSELLOUT", "ADVERTISERDISTRIBUTIONBYSELLINGNAME", "ADVERTISERPODPOSITION", "CHANGENOTICE", "COPYINSTRUCTIONSLASTUSER"
					, "DAYPARTPROJECTIONS", "ENDCREDITSQUEEZE", "FINANCEREVENUESUMMARY",
					"FLOWCHART", "INVENTORYANALYSIS", "LOGVIEW", "NEWDOLLARSBOOKED", "OPTIONS" 
					, "ORDERLETTER", "PLACEMENT", "PLANDOLLARCHANGES", "PROMOSLOTTING"
					, "PLANNINGREVENUE", "PLANSTEWARDSHIP", "PROPOSAL", "PROMOSLOTTINGADVANCE", "PROPERTYSTEWARDSHIP", "RATECARD", "RATECARDCOMPARISON"
					, "SELLINGNAMENOTONRC", "SELLINGNAMESTEWARDSHIPREPORT", "SELLINGNAMEVERIFICATION", "SELLINGNAMEREVENUE", "UNITAIRINGSNATIONAL", "UNITAIRINGSDR"};		

			////C://Users//206423258//Desktop//TVRocks//606
			////C://Users//206423258//Desktop//MondayTest//685
			//C:\Users\206423258\Desktop\Proposal_Report\Debug\683\
			////C://Users//206423258//Desktop//Proposal_Report//Debug//682682


			String zipFolderName=dateFormat.format(date)+"_Prod";
			String desktop =System.getProperty("user.home").concat("//")+"Desktop".replace("\\","//").concat("//");
			String outputPath =desktop+"Results//";
			int networkReportCount=0;
			int nonnetworkReportCount=0;


			File outputFolder = new File(desktop+"Results");
			if (outputFolder .exists()&& outputFolder.isDirectory()) {
				FileUtils.forceDelete(outputFolder);
				Thread.sleep(30000);
			}

			//Creating a temp folder "Results"	
			if (!outputFolder.exists()) {
				if (outputFolder.mkdir())
					System.out.println("Results Directory is created!");
				else 
					System.out.println("Failed to create directory!");
			}

			//Creating a zip file
			final File f = new File(backupPath+"//"+zipFolderName+".zip");
			final ZipOutputStream out = new ZipOutputStream(new FileOutputStream(f));
			out.closeEntry();
			out.close();

			//Reading each file in test case folder
			File dirSource = new File(inputPath);		
			for (File file : dirSource.listFiles()) {
				Boolean fileFound=false;
				for(int i =0; i < non_networtReports.length; i++)
				{
					if(file.getName().contains(non_networtReports[i]) )
					{
						fileFound=true;
					}
				}
				if (fileFound )
					//&& file.getName().contains(dateFormat_new.format(date))
				{
					nonnetworkReportCount++;
					{
						if(nonnetworkReportCount==1){
							//Creating a folder "Non Network" only if at least 1 file belong to the category "Non Network"
							File outputFolderNonNetwork = new File(outputPath+"NonNetwork");
							if (!outputFolderNonNetwork.exists()) {
								if (outputFolderNonNetwork.mkdir())
									System.out.println("Non Network Directory is created!");
								else 
									System.out.println("Failed to create Non Network directory!");
							}
						}
					}
					String testCaseFolderOutput =outputPath+"NonNetwork".concat("//");
					File dest = new File(testCaseFolderOutput+file.getName());
					FileUtils.moveFile(file, dest);
				}
				if (!fileFound) 
				{
					for(int i =0; i < networtReports.length; i++)
					{
						if(file.getName().contains(networtReports[i]))
						{
							fileFound=true;
						}
					}
					if (fileFound) 
					{
						networkReportCount++;
						{
							if(networkReportCount==1){
								//Creating a folder "Network" only if at least 1 file belong to the category "Network"
								File outputFolderNonNetwork = new File(outputPath+"Network");
								if (!outputFolderNonNetwork.exists()) {
									if (outputFolderNonNetwork.mkdir())
										System.out.println("Network Directory is created!");
									else
										System.out.println("Failed to create Network directory!");
								}
							}
							String testCaseFolderOutput =outputPath+"Network".concat("//");
							File dest = new File(testCaseFolderOutput+file.getName());
							try {
								FileUtils.moveFile(file, dest);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					if (!fileFound && !file.getName().contains(".png")) 
					{
						JOptionPane.showMessageDialog(null,
								"File "+file.getName()+" does not belong to either Network / Non-Network");
					}
				}
			}
			zipFolder(desktop+"Results", backupPath+"//"+zipFolderName+".zip");
		}

		catch (Exception e) {
			System.out.println("e.printStackTrace()");
		}
		System.out.println("Script is completed");
	}

	static public void zipFolder(String srcFolder, String destZipFile){
		try{
			ZipOutputStream zip = null;
			FileOutputStream fileWriter = null;

			fileWriter = new FileOutputStream(destZipFile);
			zip = new ZipOutputStream(fileWriter);
			addFolderToZip("", srcFolder, zip);

			zip.flush();
			zip.close();
			zip = null;
			fileWriter = null;
		}
		catch (Exception e) {
			System.out.println("e.printStackTrace()");
		}
	}

	static private void addFileToZip(String path, String srcFile, ZipOutputStream zip){
		try{
			FileInputStream in=null;
			File folder = new File(srcFile);
			if (folder.isDirectory()) {
				addFolderToZip(path, srcFile, zip);
			} else {
				byte[] buf = new byte[1024];
				int len;
				in = new FileInputStream(srcFile);
				zip.putNextEntry(new ZipEntry(path + "/" + folder.getName()));
				while ((len = in.read(buf)) > 0) {
					zip.write(buf, 0, len);
				}
			}
		}
		catch (Exception e) {
			System.out.println("e.printStackTrace()");
		}
	}

	static private void addFolderToZip(String path, String srcFolder, ZipOutputStream zip){
		try {
			File folder = new File(srcFolder);
			for (String fileName : folder.list()) {
				if (path.equals(""))
					addFileToZip(folder.getName(), srcFolder + "/" + fileName, zip);
				else
					addFileToZip(path + "/" + folder.getName(), srcFolder + "/" + fileName, zip);
			}
		}
		catch (Exception e) {
			System.out.println("e.printStackTrace()");
		}
	}
}
