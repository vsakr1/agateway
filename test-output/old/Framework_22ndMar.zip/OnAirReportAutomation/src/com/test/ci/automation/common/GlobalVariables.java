package com.test.ci.automation.common;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.test.automation.sat.core.SuperScript;

public class GlobalVariables extends SuperScript {

	public static ArrayList<String> JOBID = new ArrayList<>();
	public static String testDataFilePath;
	public static final String configFilePath = "..\\OnAirReportAutomation\\src\\config.properties";

}
