package com.test.ci.automation.scripts;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;
import com.sun.org.apache.bcel.internal.generic.RETURN;
import com.test.automation.sat.core.SuperScript;
import com.test.automation.sat.utils.Formatter;
import com.test.ci.automation.common.GlobalVariables;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.ReadConfigFile;

public class BaseScripts extends GlobalVariables {
	public static HashMap<String, String> config;
	public static ReadConfigFile configFile = new ReadConfigFile();
	public static WebDriver driver;
	// public static WebDriverWait wait;
	static {
		System.out.println("Base script static class is getting loaded");
		config = configFile.readConfigDataToHashMap(
				GlobalVariables.configFilePath, "=");
		GlobalVariables.testDataFilePath = config.get("TestData.path");
		exreport = new ExtentReports(config.get("LogFolder.htmlLog") + "\\"
				+ config.get("TestData.sheetName") + ".html");
		exlogger = exreport.startTest(config.get("testcase.name"));
		DOMConfigurator.configure("log4j.xml");
		
		System.out.println("Base script static class is getting loaded");
	}

	public static WebDriver createWebDriverInstance() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\testautomation-runtime\\chromedriver.exe");
		DesiredCapabilities chromeCapabilities = DesiredCapabilities.chrome();
		chromeCapabilities.setJavascriptEnabled(true);
		String[] options = { "--ignore-certificate-errors" };
		chromeCapabilities.setCapability("chrome.switches",
				Arrays.asList(options));

		String downloadFilepath = "C:\\dev\\log\\test\\test2";
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);
		ChromeOptions options1 = new ChromeOptions();
		options1.setExperimentalOption("prefs", chromePrefs);
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options1);
		driver = new ChromeDriver(cap);
		return driver;
	}

	public static void launchApplication(String url) {
		driver = SuperScript.createWebDriverInstance("chrome");
		driver.get(url);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// WebDriverWait wait = new WebDriverWait(driver, 60);
	}

	public static void launchApplicationByEnvironment(String environment) {
		System.out.println("Environmet under test is : " + environment);
		if (environment.equalsIgnoreCase("REPORTSDEV")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("BASELINE")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("DEBUG")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("INTDEV")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("QA")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("QA2")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("STAGING")||environment.equalsIgnoreCase("STAGE")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("UAT")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("PROD")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("UAT2")) {
			launchApplication(config.get(environment));
		} else if (environment.equalsIgnoreCase("TRAINING")) {
			launchApplication(config.get(environment));
		} else {
			System.out
					.println("Please specify the valid environment name in config file");
		}

	}

	public static String getJobNumber() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		driver.findElement(By.cssSelector("button.icon_job_all")).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String jobId = driver.findElement(By.cssSelector("div.x-grid3-col-id"))
				.getText();

		System.out.println(jobId + " this is the job id");
		exlogger.log(LogStatus.INFO,
				"Report succesfully generated and the job number is : " + jobId);
		return jobId;
	}

	public static String[] convertToStringArray(ArrayList<String> arryList) {
		String[] result = null;
		if (!arryList.isEmpty()) {
			result = arryList.toArray(new String[arryList.size()]);
			;
		}

		return result;
	}

	public static void updateJobNumberToTestDataSheet(String jobNumber,
			int testCaseRowNumber) {
		try {
			if (config.get("runtype").equalsIgnoreCase("pre")
					|| config.get("runtype").toLowerCase().contains("pre")) {
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Pre_Run_JobId",
						testCaseRowNumber, jobNumber);
			}
			if (config.get("runtype").equalsIgnoreCase("post")
					|| config.get("runtype").toLowerCase().contains("post")) {
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Post_Run_JobId",
						testCaseRowNumber, jobNumber);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed at the time of updating the output");
		}
	}

	public static void updateJobNumberToTestDataSheetForPostRun(
			String jobNumber, int testCaseRowNumber) {
		try {
			// if (config.get("runtype").equalsIgnoreCase("pre")
			// || config.get("runtype").toLowerCase().contains("pre")) {
			// ReadWriteTestDataSheet.updateXLSXCell(
			// config.get("TestData.path"),
			// config.get("TestData.sheetName"), "Pre-Run-JobID",
			// testCaseRowNumber, jobNumber);
			// }
			// if (config.get("runtype").equalsIgnoreCase("post")
			// || config.get("runtype").toLowerCase().contains("post")) {
			// ReadWriteTestDataSheet.updateXLSXCell(
			// config.get("TestData.path"),
			// config.get("TestData.sheetName"), "Post-Run-JobID",
			// testCaseRowNumber, jobNumber);
			// }
			ReadWriteTestDataSheet.updateXLSXCell(config.get("TestData.path"),
					config.get("TestData.sheetName"), "Post_Run_JobId",
					testCaseRowNumber, jobNumber);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed at the time of updating the output");
		}
	}

	public static void updateFileDownLoadInformationToTestDataSheet(
			Boolean status, String timeReportGeneation, int testCaseRowNumber) {
		String statusValue;
		if (status) {
			statusValue = "Success";
		} else {
			statusValue = "failure";
		}
		if (config.get("runtype").equalsIgnoreCase("pre")
				|| config.get("runtype").toLowerCase().contains("pre")) {

			try {
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Pre_Run_Status",
						testCaseRowNumber, statusValue);
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Pre_Run_Time",
						testCaseRowNumber, timeReportGeneation);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		if (config.get("runtype").equalsIgnoreCase("post")
				|| config.get("runtype").toLowerCase().contains("post")) {

			try {
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Post_Run_Status",
						testCaseRowNumber, statusValue);
				ReadWriteTestDataSheet.updateXLSXCell(
						config.get("TestData.path"),
						config.get("TestData.sheetName"), "Post_Run_Time",
						testCaseRowNumber, timeReportGeneation);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static String captureScreenShot(String screenShotPath,
			String screenShotFileName) {
		String screenShotName = "";

		// Take screenshot and store as a file format
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			// now copy the� screenshot to desired location using copyFile
			// method
			screenShotName = screenShotPath + "\\" + Formatter.getDate() + "\\"
					+ screenShotFileName + "-" + Formatter.getTime_HH_MM()
					+ ".png";
			FileUtils.copyFile(src, new File(screenShotName));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Screen shot is stored at  : " + screenShotName);
		return screenShotName;
	}

	public static void waitForPageToLoad() {
		(new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				System.out
						.println(((org.openqa.selenium.JavascriptExecutor) driver)
								.executeScript("return document.readyState")
								+ " page load");
				return (((org.openqa.selenium.JavascriptExecutor) driver)
						.executeScript("return document.readyState")
						.equals("complete"));
			}
		});
	}// Here DEFAULT_WAIT_TIME is a integer correspond to wait time in seconds

	/**
	 * 
	 * @param formatType
	 *            PDF or Formatted Excel or Unformatted Excel
	 */
	public static void exportReport(String formatType) {
		if (formatType.equalsIgnoreCase("PDF")) {
			Application_Utils
					.listOfElements(driver, "button[text()='Export to PDF']")
					.get(0).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (formatType.equalsIgnoreCase("Formatted Excel")) {
			Application_Utils
					.listOfElements(driver, "button[text()='Export to']")
					.get(0).click();
			Application_Utils
					.listOfElements(driver, "span[text()='Excel Formatted']")
					.get(0).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (formatType.equalsIgnoreCase("Unformatted Excel")) {
			Application_Utils
					.listOfElements(driver, "button[text()='Export to']")
					.get(0).click();
			Application_Utils
					.listOfElements(driver, "span[text()='Excel Unformatted']")
					.get(0).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void clickOnFilterCriteriaCheckBox() {
		driver.findElement(
				By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]"))
				.click();
	}

	public static void waitUntilFileIsDownLoaded() {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy--HH.mm.ss");
		Date beforeFileDownLoad;
		Date fileModifiedTime;
		try {
			beforeFileDownLoad = sdf.parse(Formatter.getTimeStamp());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
