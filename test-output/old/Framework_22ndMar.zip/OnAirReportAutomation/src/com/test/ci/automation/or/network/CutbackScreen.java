package com.test.ci.automation.or.network;

public class CutbackScreen {
	public static final String CUTBACKREPORT = "linkText=Cutback Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTQUARTER = "xpath=//span[text()='Start Quarter']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDQUARTER = "xpath=//span[text()='End Quarter']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FILTERCRITERIA = "xpath=//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
