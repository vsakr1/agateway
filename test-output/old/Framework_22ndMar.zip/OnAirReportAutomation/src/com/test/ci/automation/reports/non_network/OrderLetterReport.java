
package com.test.ci.automation.reports.non_network;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.OrderLetterScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class OrderLetterReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException, IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");

		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {
			launchApplicationByEnvironment(config.get("ENV"));
			waitForWindowTitle("Dashboard");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Order Letter"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Order Letter"))));
			driver.findElement(By.linkText("Order Letter")).click();
			System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
			Thread.sleep(2000);

			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {
				try {
					if (ReadWriteTestDataSheet.excelText(sheetNumber,"RunMode", i).equalsIgnoreCase("N")
							|| ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("No")) 
					{
					} 
					else 
					{
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());

						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						actionDriver(Link, OrderLetterScreen.CLEARFORM, "Click", "Clear Form", "Landing Page");

						// General tab
						driver.findElement(By.linkText("General")).click();		
						//Application_Utils.waitWhileLoading(driver);
						driver.findElement(By.xpath("//span[text()='Search Plans']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "searchplans", i));
						Thread.sleep(2000);
						Actions actions=new Actions(driver);
						actions.sendKeys(Keys.ENTER).perform();
						//Application_Utils.waitWhileLoading(driver);
						Thread.sleep(5000);

						driver.findElement(By.xpath("//span[text()='Agency Contact']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "agencycontact", i));	
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='Agency Contact']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "agencycontact", i)))
							Log.error("Agency Contact Value is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "agencycontact", i));

						driver.findElement(By.xpath("//span[text()='Added Value']/following::a[contains(@class,'xcheckbox-off')]")).click();	
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Added Value']/following::textarea")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "addvalue", i));
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='Added Value']/following::textarea")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "addvalue", i)))
							Log.error("Added Value is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "addvalue", i));

						driver.findElement(By.xpath("//span[text()='CC']/following::a[contains(@class,'xcheckbox-off')]")).click();	
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='CC']/following::textarea")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "cc", i));
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='CC']/following::textarea")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "cc", i)))
							Log.error("CC Value is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "cc", i));


						exportReport("PDF");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			driver.close();
			driver.quit();
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}