package com.test.ci.automation.or.non_network;


public class SellingNameRevenueScreen {
	
	public static final String SELLINGNAMEREVENUEREPORT = "linktext=Selling Name Revenue Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CALENDAR = "xpath=//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FIELDLABEL = "xpath=//span[@class='field_label' and text()='Plan Data']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SPOTSTATUS = "xpath=//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String COMMERCIALTYPEGROUP = "xpath=//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO1 = "xpath =//span[text()='Demo 1']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO2 = "xpath =//span[text()='Demo 2']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String INCLUDEWMLTOTAL = "xpath =//span[text()='Include WML Total']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String INVENTORY = "xpath =//span[text()='Inventory']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String SHOWPLANDETAIL = "xpath =//span[text()='Show Plan Detail']/following::a[contains(@class,'xcheckbox')]";
	public static final String PRIMARYGROUPBY = "xpath =//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPARTGROUPING = "xpath =//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSORT = "xpath =//span[text()='Plan Sort']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REVENUETYPE = "xpath =//span[text()='Revenue Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPARTSUMMARY = "xpath =//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";

}
