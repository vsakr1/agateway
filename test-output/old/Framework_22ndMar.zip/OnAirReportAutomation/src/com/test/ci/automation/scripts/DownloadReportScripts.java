package com.test.ci.automation.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.test.ci.automation.common.FileDownloaderUtility;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.utils.Formatter;

public class DownloadReportScripts extends BaseScripts {
	@Test
	public void runDownloadReport() {
		try {
			FileDownloaderUtility.deleteExistingFiles(config
							.get("deafaultFolder.path"));
			String startTimeInt = Formatter.getTimeStamp();
			boolean downLoadStatus = false;
			String sheetName = config.get("TestData.sheetName");
			launchApplicationByEnvironment(config.get("ENV"));
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Finance Revenue Summary Report"))));
			driver.findElement(By.cssSelector("button.icon_job_all")).click();
			Thread.sleep(3000);
			int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config
					.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i)
						.equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber,
								"RunMode", i).equalsIgnoreCase("No")) {
					/**
					 * this will not execute the test case
					 */
				} else {
					driver.findElement(By.cssSelector("button.icon_job_all"))
							.click();
					Thread.sleep(3000);
					driver.findElement(By.name("jobSearch")).clear();
					Thread.sleep(3000);
					String jobId = "";
					if (config.get("runtype").equalsIgnoreCase("post")
							|| config.get("runtype").contains("post")) {
						jobId = ReadWriteTestDataSheet.excelText(sheetNumber,
								"Post_Run_JobId", i);
					} else {
						jobId = ReadWriteTestDataSheet.excelText(sheetNumber,
								"Pre_Run_JobId", i);
					}
					driver.findElement(By.name("jobSearch")).sendKeys(jobId);
					driver.findElement(
							By.cssSelector("img.x-form-search-trigger"))
							.click();
					Thread.sleep(3000);
					String starTime = driver
							.findElement(
									By.cssSelector("div.x-grid3-col-executionStartDate"))
							.getText().trim();
					String endTime = driver
							.findElement(
									By.cssSelector("div.x-grid3-col-executionEndDate"))
							.getText().trim();
					System.out
							.println(driver
									.findElement(
											By.cssSelector("div.x-grid3-col-executionStartDate"))
									.getText().trim());
					System.out
							.println(driver
									.findElement(
											By.cssSelector("div.x-grid3-col-executionEndDate"))
									.getText().trim());
					System.out.println("bero43 date");
					String timeTakenForReportToGenerate = Formatter
							.getDateDiffInMin(starTime, endTime);
					String timeBeforeFileDownload = Formatter.getTimeStamp();
					Thread.sleep(1001);
					if (!(driver.findElements(By
							.cssSelector("div.rowAction[qtip=Download]")))
							.isEmpty()) {
						System.out.println("present");
						driver.findElement(
								By.cssSelector("div.rowAction[qtip=Download]"))
								.click();
						downLoadStatus = true;
					} else {
						driver.findElement(
								By.cssSelector("button.icon_job_aborted"))
								.click();
						Thread.sleep(3000);
						driver.findElement(By.name("jobSearch"))
								.sendKeys(jobId);
						driver.findElement(
								By.cssSelector("img.x-form-search-trigger"))
								.click();
						Thread.sleep(3000);
						System.out.println("data is not present");
						String errorScreen = captureScreenShot(
								config.get("LogFolder.screenShot"), i + "");

					}
					
					FileDownloaderUtility.waitUntilFileIsDownLoaded(config
							.get("deafaultFolder.path"),timeBeforeFileDownload);
					Thread.sleep(3000);
					String filePath = FileDownloaderUtility.moveFiles(jobId, i);
					Thread.sleep(3000);

					updateFileDownLoadInformationToTestDataSheet(
							downLoadStatus, timeTakenForReportToGenerate, i);
					driver.findElement(
							By.cssSelector("img.x-form-clear-trigger")).click();
					Thread.sleep(3000);
				}

			}
			String endTimeInt = Formatter.getTimeStamp();
			System.out.println("Execution Time taken for \""
					
				+ " is "
				+ Formatter.getTimeLapsed(startTimeInt,
						endTimeInt) + " minute(s)\n");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
