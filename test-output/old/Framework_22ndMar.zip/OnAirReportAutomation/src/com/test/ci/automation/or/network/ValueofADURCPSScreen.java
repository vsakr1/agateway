package com.test.ci.automation.or.network;

public class ValueofADURCPSScreen {
	public static final String VALUEOFADURCPSREPORT = "linkText=Value of ADU/RCPS Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DIVISIONDAYPART = "xpath=//span[text()='Division (Daypart)']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPART = "xpath=//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SHOWSTATUS = "xpath=//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ADURCPSTARTDATE = "xpath=//span[text()='ADU/Rcp Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ADURCPENDDATE = "xpath=//span[text()='ADU/Rcp End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEALYEAR = "xpath=//span[text()='Deal Year']/following::span[text()='Filter by Name']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSTATUS = "xpath=//span[text()='Plan Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
