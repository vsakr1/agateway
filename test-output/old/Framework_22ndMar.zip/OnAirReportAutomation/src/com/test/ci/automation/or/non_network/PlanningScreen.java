package com.test.ci.automation.or.non_network;

public class PlanningScreen {
	
	public static final String PLANNINGREVENUEREPORT = "linktext=Planning Revenue Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String CALENDAR = "xpath=//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REVENUE = "xpath=//span[text()='Revenue']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSTATUS = "xpath=//span[text()='Plan Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String MARKETPLACE = "xpath=//span[text()='Marketplace']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SPOTSTATUS = "xpath=//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REPORTVERSION = "xpath=//span[text()='Report Version']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DISPLAYATTRIBUTES = "xpath=//span[text()='Display Attributes']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SUPPRESSPLANDETAIL = "xpath=//span[text()='Suppress Plan Detail']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String DISPLAYMETRICSPERIOD = "xpath=//span[text()='Display Metrics (Period)']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DISPLAYMETRICSTOTAL = "xpath=//span[text()='Display Metrics (Total)']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CORPORATEDEMO = "xpath=//span[text()='Corporate Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FILTERCRITERIA = "xpath=//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String PRIMARYGROUPBY = "xpath=//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SECONDARYGROUPBY = "xpath=//span[text()='Secondary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";
																			
																			

}
