package com.test.ci.automation.utils;
import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class MulipleExecution {
	//Time in minutes
	static int time=10;
	public static void main(String args[]) throws Exception{
			try
			{
				FileInputStream fileIStreamTEF = null;						 
				File TEFlow = null;

				TEFlow = new File("C:\\Test\\DataSheet\\ExecutionFlow.xlsx");
				fileIStreamTEF = new FileInputStream(TEFlow);			
				Workbook TEFWorkbook = WorkbookFactory.create(fileIStreamTEF);
				Sheet Sequence = TEFWorkbook.getSheet("Sequence");

				for(int n=1;n<=Sequence.getLastRowNum();n++)
				{
					System.out.println("Execution Completed="+n);
					Thread.sleep(time*10000);
				}
				System.exit(0);
			}
			catch(Exception e){ e.getMessage();}
		}
	}


