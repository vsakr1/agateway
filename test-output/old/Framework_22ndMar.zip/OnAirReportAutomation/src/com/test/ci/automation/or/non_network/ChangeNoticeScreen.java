package com.test.ci.automation.or.non_network;

public class ChangeNoticeScreen {
	public static final String CHANGENOTICEREPORT = "linktext=Change Notice Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PLANDATA = "";
	public static final String SEARCH = "xpath = //button[text()='Search']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REVISIONS = "xpath =//span[text()='Revisions']/following::div[contains(@class,'x-grid3-row-checker')][last()]";
	public static final String FORMATTING = "";
	public static final String CHANGENOTICEDISPLAY = "xpath =//span[text()='Change Notice Display']/following::input[contains(@class,'x-form-text x-form-field')]";
	

}
