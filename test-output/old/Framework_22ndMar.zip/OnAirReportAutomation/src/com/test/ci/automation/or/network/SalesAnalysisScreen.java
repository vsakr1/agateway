package com.test.ci.automation.or.network;

public class SalesAnalysisScreen {
	public static final String SALEANALYSISREPORT = "linkText=Sales Analysis Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SHOWSTATUS = "xpath=//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSTATUS = "xpath=//span[text()='Plan Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SPOTSTATUS = "xpath=//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DETAILLEVEL = "xpath=//span[text()='Detail Level']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTOPDF = "xpath=//button[text()='Export to PDF']";
}
