package com.test.ci.automation.or.non_network;

public class ProposalScreen {
	
	public static final String PROPOSALREPORT = "linktext=Proposal Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String SEARCHCOMBO = "xpath=//input[@id='searchcombo' and contains(@class,'x-form-text x-form-field')]";
	public static final String ADMINHISTORYBUTTON = "xpath=//input[@id='adminHistoryButton' and contains(@class,'x-form-text x-form-field')]";
	public static final String NEXT = "xpath=//button[text()='Next']";
	

	
	
}
