package com.test.ci.automation.or.network;

public class PromoRatingsScreen {
	public static final String PROMORATINGSREPORT = "linkText=Promo Ratings Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO = "xpath=//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath=//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String MasterRatecard = "xpath=//span[text()='Master Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYSORTBY = "xpath=//span[@class='field_label' and text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
