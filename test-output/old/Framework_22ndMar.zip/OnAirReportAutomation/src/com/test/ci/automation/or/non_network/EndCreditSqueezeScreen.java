package com.test.ci.automation.or.non_network;

public class EndCreditSqueezeScreen {
	public static final String ENDCREDITSQUEEZEREPORT = "linktext=End Credit Squeeze Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYTYPE = "xpath =//span[text()='Day Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FORMATTING = "";
	public static final String FILTERCRITERIA = "xpath =//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";

}
