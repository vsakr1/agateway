package com.test.ci.automation.or.network;

public class CommercialPositionScreen {
	public static final String CommercialPositionReport = "linkText=Commercial Position Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SHOWSTATUS = "xpath=//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPART = "xpath=//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTOPDF = "xpath=//button[text()='Export to PDF']";
}
