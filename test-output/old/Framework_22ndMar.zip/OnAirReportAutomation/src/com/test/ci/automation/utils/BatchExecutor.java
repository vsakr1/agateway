package com.test.ci.automation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class BatchExecutor {

	//public static String settingFilePath =Application_Utils.environmentSelection().replace("\\","//");
	public static int scheduleTime=0;
	public static int timeSelected;
	public static String environment;

	public static void main(String args[]) throws Exception{

		SimpleDateFormat df = new SimpleDateFormat("dd_MMM_hh_mm_ss");  
		Date date = new Date(); 
		String formattedDate= df.format(date);

		PrintStream out = new PrintStream(new FileOutputStream("Result_On_"+formattedDate+".txt"));
		System.setOut(out);
		Timer timer = new Timer();
		TimerTask tt = new TimerTask() {
			@Override
			public void run() {


				Calendar cal = Calendar.getInstance(); 
				int hour = cal.get(Calendar.HOUR_OF_DAY);
				//HOUR_OF_DAY
				/*if(scheduleTime==0){
					JPanel panel = new JPanel();
					panel.add(new JLabel("Please select the time for executing the \"Batch Execution\""));
					String time[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
							"11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
							"21", "22", "23", "24" };
					DefaultComboBoxModel model = new DefaultComboBoxModel(time);
					JComboBox comboBox = new JComboBox(model);
					panel.add(comboBox);
					int result = JOptionPane.showConfirmDialog(null, panel, "Batch Executor", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);

					switch (result) {
					case JOptionPane.OK_OPTION:
						break;
					}
					timeSelected=Integer.valueOf((String)comboBox.getSelectedItem()).intValue();
					scheduleTime++;
				}	*/


				System.out.println("Batch Execution will start while the selected time equal to system time...");
				//if (Integer.valueOf((String)comboBox.getSelectedItem()).intValue()==hour)
				if(scheduleTime==hour)
				{
					try 
					{
						ClassLoader loader = ClassLoader.getSystemClassLoader();
						FileInputStream fileIStreamTEF = null;						 
						File TEFlow = null;
						try{	
							TEFlow = new File("C:\\Test\\DataSheet\\ExecutionFlow.xlsx");
							fileIStreamTEF = new FileInputStream(TEFlow);			
							Workbook TEFWorkbook = WorkbookFactory.create(fileIStreamTEF);
							Sheet Sequence = TEFWorkbook.getSheet("Sequence");
							long start=0;
							for(int n=1;n<=Sequence.getLastRowNum();n++)
							{
								//System.out.println("\n");
								environment = Application_Utils.getExcelValue(Sequence,n,3);
								Application_Utils.setFilePath(environment);
								String TCName = Application_Utils.getExcelValue(Sequence,n,1);
								String executionFlag = Application_Utils.getExcelValue(Sequence,n,2);
								
								String category = Application_Utils.getExcelValue(Sequence,n,4);
								if (!("".equals(TCName.trim()))&&"Y".equalsIgnoreCase(executionFlag.trim()))
								{	
									try
									{
										//start = System.currentTimeMillis();
										Class<?> myClass = loader.loadClass(category+".".concat(TCName));
										Method[] myMethods = myClass.getDeclaredMethods();
										for(Method method : myMethods) {

											if("runScript".equalsIgnoreCase(method.getName())) {
												method.getGenericReturnType();
												method.invoke(myClass.newInstance(), null);
											}											
										}
									} 

									catch (ClassNotFoundException e) {
										e.printStackTrace();
									} catch (SecurityException e) {
										e.printStackTrace();
									} catch (IllegalAccessException e) {
										e.printStackTrace();
									} catch (IllegalArgumentException e) {
										e.printStackTrace();
									} catch (InvocationTargetException e) {
										e.printStackTrace();
									} catch (InstantiationException e) {
										e.printStackTrace();
									}
								}
								//long end = System.currentTimeMillis();
								//NumberFormat formatter = new DecimalFormat("#0.00000");
								//System.out.print("Execution time is taken for script "+TCName+" is "+formatter.format((end - start) / 1000d) + " seconds");	
							}
							System.exit(0);
						}

						catch(Exception e){ e.getMessage();}
					}
					catch(Exception e){ e.getMessage();}

				}
			}
		};
		timer.schedule(tt, 10000, 1);
	}
}


