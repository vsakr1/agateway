package com.test.ci.automation.or.non_network;


public class PropertyStewardshipScreen {
	
	public static final String PROPERTYSTEWARDSHIPREPORT = "linktext=Property Stewardship Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String REPORTTYPE =  "xpath = //span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String GUARANTEEDSTATUS = "xpath=//span[text()='Guaranteed Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSTATUS = "xpath=//span[text()='Plan Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANSUMMARY = "xpath=//span[text()='Plan Summary']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String GUARANTEED = "xpath=//span[text()='Guaranteed']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String ACTUALANDPROJECTED = "xpath=//span[text()='Actual & Projected']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String SUMMARY = "xpath=//span[text()='Summary']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String PLANLINKDETAIL = "xpath=//span[text()='Plan Link Detail']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String PRIMARYSORTBY = "xpath=//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";

}
