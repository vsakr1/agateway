package com.test.ci.automation.reports.network;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.network.CommercialFormatScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

public class CommercialFormatReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException,
			IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		// Assigning the environment
		String[] tabs = { "General", "Formatting" };

		// Application_Utils.setSettingsFileNamePath(settingsFileName);
		// Application_Utils.setReportName(sheetName);
		/**
		 * new code
		 */
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {
			// launch application
			launchApplication(config.get("DEBUG"));

			System.out.println(driver.findElement(By.cssSelector("div.x-tip"))
					.getText()
					+ " this is the text after we launch application");
			// wait for the title
			waitForWindowTitle("Dashboard");
			Thread.sleep(10000);
			System.out.println(driver.getCurrentUrl());
			WebDriverWait wait = new WebDriverWait(driver, 60);
			WebDriverWait waitForPageLoad = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
					.linkText("Commercial Format Report"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver
					.findElement(By.linkText("Commercial Format Report"))));
			driver.findElement(By.linkText("Commercial Format Report")).click();
			System.out
					.println(((org.openqa.selenium.JavascriptExecutor) driver)
							.executeScript("return document.readyState")
							+ " document status");
			Thread.sleep(2000);
			/**
			 * new code
			 */
			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config
					.get("TestData.sheetName"))/* i<2 */; i = i + 1) {

				try {

					if (ReadWriteTestDataSheet.excelText(sheetNumber,
							"RunMode", i).equalsIgnoreCase("N")
							|| ReadWriteTestDataSheet.excelText(sheetNumber,
									"RunMode", i).equalsIgnoreCase("No")) {
						/**
						 * this will not execute the test case
						 */
					} else {
						/**
						 * This will strat script execution
						 */

						// we will copy the code here once every thing is
						// working as expected
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						// Initializing the driver
						// WebDriver driver = Application_Utils.assignDriver();
						// WebDriverWait wait = new WebDriverWait(driver, 60);
						// //Application_Utils.excelUpdate();
						//
						// DOMConfigurator.configure("log4j.xml");
						Logger Log = Logger.getLogger(Log.class.getName());
						//
						// Application_Utils.launch(driver);

						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						// driver.findElement(
						// By.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))
						// .click();
						actionDriver(Link, CommercialFormatScreen.CLEARFORM,
								"Click", "Clear Form", "Landing Page");
						Thread.sleep(5000);

						// Clicking the "General" Tab
						driver.findElement(By.linkText("" + tabs[0] + ""))
								.click();
						Thread.sleep(2000);

						driver.findElement(
								By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "property", i));
						driver.findElement(
								By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);

						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "property", i))))
							Log.error("Property is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "property", i));

						driver.findElement(
								By.xpath("//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "showstatus", i));
						driver.findElement(
								By.xpath("//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "showstatus", i))))
							Log.error("Show Status is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "showstatus", i));

						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.clear();
						Thread.sleep(2000);
						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "startdate", i));
						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "startdate", i))))
							Log.error("Start Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "startdate", i));

						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.clear();
						Thread.sleep(2000);
						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "enddate", i));
						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "enddate", i))))
							Log.error("End Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "enddate", i));
						waitForPageToLoad();
						driver.findElement(
								By.xpath("//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypart", i));
						driver.findElement(
								By.xpath("//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "daypart", i))))
							Log.error("Daypart is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "daypart", i));

						Application_Utils.checkItemInSelect(driver,
								"Commercial Type Group", ReadWriteTestDataSheet
										.excelText(sheetNumber,
												"commercialtypegroup", i));
						Wait<WebDriver> waitForLoad = new WebDriverWait(driver,
								20);
						waitForPageToLoad();

						// waitForPageLoad.until(ExpectedConditions
						// .invisibilityOfElementWithText(
						// By.cssSelector("div.x-mask-loading"),
						// "Please wait. Loading data.."));
						// Application_Utils.waitWhileLoading(driver);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.getAttribute("value")
								.equals(ReadWriteTestDataSheet.excelText(
										sheetNumber, "commercialtypegroup", i))))
							Log.error("Commercial Type Group is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "commercialtypegroup",
											i));

						if (ReadWriteTestDataSheet.excelText(sheetNumber,
								"Planned/Actual Log", i)
								.equalsIgnoreCase("Yes")
								|| ReadWriteTestDataSheet.excelText(
										sheetNumber, "RunMode", i)
										.equalsIgnoreCase("True")
								|| ReadWriteTestDataSheet.excelText(
										sheetNumber, "RunMode", i)
										.equalsIgnoreCase("Check")) {
							driver.findElement(
									By.cssSelector("a.xcheckbox-off")).click();
							Thread.sleep(2000);
						} else {
							driver.findElement(
									By.xpath("//span[text()='Alternate Log']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.sendKeys(
											ReadWriteTestDataSheet.excelText(
													sheetNumber,
													"alternatelog", i));
							driver.findElement(
									By.xpath("//span[text()='Alternate Log']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.sendKeys(Keys.ENTER);
							Thread.sleep(2000);
							if (!(driver
									.findElement(
											By.xpath("//span[text()='Alternate Log']/following::input[contains(@class,'x-form-text x-form-field')]"))
									.getAttribute("value")
									.equals(ReadWriteTestDataSheet.excelText(
											sheetNumber, "alternatelog", i))))
								Log.error("Alternate Log is not "
										+ ReadWriteTestDataSheet.excelText(
												sheetNumber, "alternatelog", i));
						}
						// click on scheck box

						// Clicking the "Spot Data" Tab
						driver.findElement(By.linkText("" + tabs[1] + ""))
								.click();
						Thread.sleep(3000);
						if (!ReadWriteTestDataSheet.excelText(sheetNumber,
								"optionalcolumns", i).equals("")) {
							Application_Utils.checkItemInSelect(driver,
									"Optional Columns", ReadWriteTestDataSheet
											.excelText(sheetNumber,
													"optionalcolumns", i));
							Thread.sleep(3000);
						}
						
						
						/**
						 * common
						 * New code starts here
						 */
						clickOnFilterCriteriaCheckBox();
						
						Thread.sleep(2000);
						//PDF or Formatted Excel or  Unformatted Excel
						exportReport("Unformatted Excel");

						
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						/**
						 * New code ends here
						 */
						// Application_Utils.validateReportGeneration(driver,
						// i);

						// Application_Utils.excelToWrite(config.get("Report.OutPut.path"),sheetName,"JobNumber",
						// getJobNumber(), i);
						String endTimeIs = Formatter.getTimeStamp();

						System.out.println("Execution Time taken for \""
								+ sheetName
								+ "\" report for iteration "
								+ i
								+ " is "
								+ Formatter.getTimeLapsed(startTimeIs,
										endTimeIs) + " minute(s)\n");
						driver.findElement(By.cssSelector("div.x-tool-close"))
								.click();

					}

				} catch (Exception e) {
					e.printStackTrace();
					System.out
							.println("-----------------------------------------");
					System.out.println(e.getMessage());
					System.out.println("Row " + i
							+ " : Script has not been executed");
					System.out
							.println("-----------------------------------------");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally {
			driver.close();
			driver.quit();
			exreport.endTest(exlogger);

		}
		exreport.flush();
		// try {
		// if (config.get("runtype").equalsIgnoreCase("pre")
		// || config.get("runtype").toLowerCase().contains("pre")) {
		// ReadWriteExcelFile.updateXLSXColomn(
		// config.get("TestData.path"), "commercialformat",
		// "Pre-Run-JobID", convertToStringArray(JOBID));
		// }
		// if (config.get("runtype").equalsIgnoreCase("post")
		// || config.get("runtype").toLowerCase().contains("post")) {
		// ReadWriteExcelFile.updateXLSXColomn(
		// config.get("TestData.path"), "commercialformat",
		// "PostRunJobID", convertToStringArray(JOBID));
		// }
		//
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// System.out.println("Failed at the time of updating the output");
		// }

	}
}
