package com.test.ci.automation.or.non_network;

public class SellingNameStewardshipScreen {
	public static final String SELLINGNAMESTEWARDSHIPREPORT = "linkText=Selling Name Stewardship Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CALENDAR = "xpath=//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO = "xpath=//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DOLLARVARIANCE = "xpath=//span[text()='Dollar Variance']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYGROUPBY = "xpath=//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
