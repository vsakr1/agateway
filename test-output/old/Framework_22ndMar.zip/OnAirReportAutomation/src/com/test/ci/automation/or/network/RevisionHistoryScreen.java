package com.test.ci.automation.or.network;

public class RevisionHistoryScreen {
	public static final String REVISIONHISTORYREPORT = "linkText=Revision History Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String SEARCHPLANS = "id=searchcombo_revisionHistory";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
