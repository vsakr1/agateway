package com.test.ci.automation.or.non_network;


public class PlanStewardshipScreen {
	
	public static final String PLANSTEWARDSHIPREPORT = "linktext=Plan Stewardship Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANLINKID = "xpath=//span[text()='Plan #/Link ID']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String USEHH = "xpath=//span[text()='Use HH']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String USEDEMO = "xpath=//span[text()='Use Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PROJECTIONBY = "xpath=//span[text()='Projection By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String BREAKDOWN = "xpath=//span[text()='Breakdown']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String BASIS = "xpath=//span[text()='Basis']/following::input[contains(@class,'x-form-text x-form-field')]";
}
