package com.test.ci.automation.or.non_network;

public class DaypartProjectionsScreen {
	
	public static final String DAYPARTPROJECTIONSREPORT = "linktext=Daypart Projections Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String QUARTER = "xpath =//span[text()='Quarter']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO1 = "xpath//span[text()='Demo 1']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPARTGROUPING = "xpath = //span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FORMATTING = "";
	public static final String FILTERCRITERIA= "xpath =//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";

}
