package com.test.ci.automation.or.non_network;

public class RatecardComparisonScreen {
	
	public static final String RATECARDCOMPARISONREPORT = "linktext=Ratecard Comparison Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATECARD = "xpath =//span[text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String UNIVERSE = "xpath =//span[text()='Universe']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RCLINESTATUS = "xpath =//span[text()='RC Line Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String VARIANCEDISPLAY = "xpath =//span[text()='Variance Display']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath =//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYGROUPBY = "xpath =//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";

}
