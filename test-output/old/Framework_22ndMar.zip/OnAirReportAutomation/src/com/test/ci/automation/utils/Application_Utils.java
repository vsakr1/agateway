package com.test.ci.automation.utils;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.ci.automation.scripts.BaseScripts;

public class Application_Utils extends BaseScripts {

	private static String reportName;
	// private static String settingsFilePath =
	// "C://Test//settings//settings_T5-UAT2.xlsx";
	// private static String settingsFilePath =
	// "C://Test//settings//settings_debug.xlsx";
	private static String settingsFilePath = "C://Test//settings//settings_prod.xlsx";
	// private static String settingsFilePath;
	private static String filePath = settings(reportName + "report").replace(
			"\\", "//");
	static int complete = 0;

	private static String execStartTime = "";
	private static String execEndTime = "";

	WebDriver driver;

	public static void setFilePath(final String environment) {
		// settingsFilePath = "C://Test//settings//settings_" + environment
		// + ".xlsx";
	}

	// public static String getSettingsFilePath() {
	// return settingsFilePath;
	// }

	// public static void setSettingsFileNamePath(String settingFileName_clone)
	// {
	//
	// String settingFilePathNew = settingsFilePath.concat("//").concat(
	// settingFileName_clone);
	// settingsFilePath = settingFilePathNew;
	//
	// }

	// public static String environmentSelection() {
	// try {
	// String filename = null;
	// while (filename == null) {
	// JFileChooser fileChooser = new JFileChooser();
	// int option = fileChooser.showOpenDialog(fileChooser);
	// if (option == JFileChooser.APPROVE_OPTION) {
	// filename = fileChooser.getSelectedFile().getPath();
	// settingsFilePath = filename;
	// return settingsFilePath;
	// }
	// }
	// return filename;
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// // String filename = "Error";
	// // return filename;
	// return settingsFilePath;
	// }

	public static void loadLog() {
		DOMConfigurator.configure("log4j.xml");
		Logger Log = Logger.getLogger(Log.class.getName());
	}

	// Setting the value of the excel sheet name from the script
	public static void setReportName(String reportName_clone) {
		reportName = reportName_clone;
		filePath = settings(reportName + "report").replace("\\", "//");
	}

	public static WebDriver assignDriver() {
		try {
			/*
			 * System.setProperty("webdriver.chrome.driver",settings(
			 * "chromewebdriver").replace("\\", "//")); DesiredCapabilities
			 * capabilities=DesiredCapabilities.chrome(); String
			 * chromeBinary=System.getProperty("chrome.binary"); if
			 * (StringUtils.isNotBlank(chromeBinary)) {
			 * capabilities.setCapability("chrome.binary",chromeBinary); }
			 */
			// return new ChromeDriver(capabilities);

			/*
			 * DesiredCapabilities chromeCapabilities = DesiredCapabilities
			 * .chrome(); chromeCapabilities.setJavascriptEnabled(true);
			 * String[] options = {
			 * "--disable-popup-blocking","--ignore-certificate-errors" };
			 * chromeCapabilities.setCapability("chrome.switches",
			 * Arrays.asList(options));
			 */

			// driver = new RemoteWebDriver(DesiredCapabilities.chrome());
			// WebDriver driverObj = new ChromeDriver(capabilities);

			/*
			 * System.setProperty("webdriver.chrome.driver",settings(
			 * "chromewebdriver").replace("\\", "//")); DesiredCapabilities
			 * dc=DesiredCapabilities.chrome(); String[]
			 * switches={"--ignore-certificate-errors"
			 * ,"--disable-popup-blocking","--disable-translate"};
			 * 
			 * dc.setCapability("chrome.switches",Arrays.asList(switches));
			 * 
			 * WebDriver driverObj = new ChromeDriver(dc);
			 */
			// System.setProperty("webdriver.chrome.driver",settings("chromewebdriver").replace("\\",
			// "//"));
			/*
			 * WebDriver driverObj = new ChromeDriver();
			 * driverObj.manage().window().maximize();
			 * driverObj.manage().timeouts().implicitlyWait(40,
			 * TimeUnit.SECONDS); return driverObj;
			 */

			// chromeOptions.put("binary",
			// "/usr/lib/chromium-browser/chromium-browser");
			// String[] options = { "binary",
			// "/usr/lib/chromium-browser/chromium-browser"};
			// DesiredCapabilities dc=DesiredCapabilities.chrome();
			// String[]
			// switches={"--ignore-certificate-errors","--disable-popup-blocking","--disable-translate"};

			// dc.setCapability("chrome.switches",Arrays.asList(switches));
			/*
			 * String[]
			 * options={"--ignore-certificate-errors","--disable-popup-blocking"
			 * ,"--disable-translate"}; DesiredCapabilities capabilities =
			 * DesiredCapabilities.chrome();
			 * capabilities.setCapability(ChromeOptions.CAPABILITY,
			 * Arrays.asList(options));
			 */
			// System.setProperty("webdriver.chrome.driver",settings("chromewebdriver").replace("\\",
			// "//"));
			/*
			 * DesiredCapabilities dc=DesiredCapabilities.chrome(); String[]
			 * switches={"--disable-popup-blocking"};
			 * 
			 * dc.setCapability("chrome.switches",Arrays.asList(switches));
			 */
			// ChromeOptions options = new ChromeOptions(dc);

			System.setProperty("webdriver.chrome.driver",
					settings("chromewebdriver").replace("\\", "//"));
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-popup-blocking");
			ChromeDriver driverObj = new ChromeDriver(options);

			// System.setProperty("webdriver.chrome.driver",settings("chromewebdriver").replace("\\",
			// "//"));
			// WebDriver driverObj = new ChromeDriver();

			// WebDriver driverObj = new ChromeDriver(options);
			driverObj.manage().window().maximize();

			driverObj.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

			driverObj.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			return driverObj;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	// public static int checkMandatoryFieldErrorIcon(WebDriver driver, int i) {
	public static void checkMandatoryFieldErrorIcon(String[] tabs,
			WebDriver driver, int i) {
		try {
			String servicePackNumber = Application_Utils
					.connectDB(Application_Utils.settings("servicepackquery"));
			Application_Utils.moveFiles(servicePackNumber.replaceAll(";", ""),
					i);
			String patchFolder = "//" + servicePackNumber.replaceAll(";", "");
			String targetFolder = settings("reportfolder");
			File dirTarget = new File(targetFolder + patchFolder);
			if (!dirTarget.exists()) {
				dirTarget.mkdir();
				System.out.println(dirTarget.getAbsolutePath());
			}

			for (int tabNumber = 0; tabNumber < tabs.length; tabNumber++) {
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Boolean found = false;

				try {
					found = driver
							.findElement(
									By.xpath("//span[text()='"
											+ tabs[tabNumber]
											+ "'][contains(@class,'form-tab-invalid')]"))
							.isDisplayed();
				} catch (Exception e) {
				}

				if (found) {
					driver.findElement(By.linkText("" + tabs[tabNumber] + ""))
							.click();
					Date creationDate = new Date();
					DateFormat df = new SimpleDateFormat("ddMMMyyyy_HHmmss");// H:24
																				// hrs,
																				// h:
																				// 12hrs
					File destination = new File(dirTarget + "//" + reportName
							+ "_" + df.format(creationDate) + "_" + i + "_"
							+ servicePackNumber.replaceAll(";", "") + ".png");
					BufferedImage image = new Robot()
							.createScreenCapture(new Rectangle(Toolkit
									.getDefaultToolkit().getScreenSize()));
					ImageIO.write(image, "png",
							new File(destination.toString()));
					Thread.sleep(5000);
					// return -1;

					System.out
							.println("\n------------------------------------------------------------------\n"
									+ "Either the locator is incorrect (or) Data is incorrect (or) Blank\nPlease refer the screenshot(s)\n"
									+ "------------------------------------------------------------------\n");
					Application_Utils.moveFiles(
							servicePackNumber.replaceAll(";", ""), i);
					String[] status = { "Fail" };
					Application_Utils.excelWrite(reportName, "status", status,
							i);

					FileInputStream file = new FileInputStream(new File(
							filePath));
					XSSFWorkbook workbook = new XSSFWorkbook(file);
					XSSFSheet sheet = workbook.getSheetAt(0);

					// sheet.get
					Row temprow = sheet.getRow(i);
					// Column tempcolumn=sheet.get
					int noOfColumns = sheet.getRow(0)
							.getPhysicalNumberOfCells();
					Cell tempCell = temprow.getCell(noOfColumns - 1);

					/*
					 * int columnWidht=
					 * System.out.println("columnWidht="+columnWidht);
					 * 
					 * 
					 * 
					 * 
					 * Iterator colIter = sheet. Column tempcolumn =
					 * (Column)colIter.next(); short lastCellNum =
					 * r.getLastCellNum(); int[] dataCount = new
					 * int[lastCellNum];
					 */

					/*
					 * XSSFRow cellColumn = sheet.getRow(0); int cellCount =
					 * cellColumn.length; System.out.println("cells in col: " +
					 * cellCount);
					 */

					if (tempCell == null) {
						tempCell = temprow.createCell(noOfColumns - 1);
					}
					String statusValue = "Fail";
					String linkFormula = "HYPERLINK(\"" + dirTarget + "\",\""
							+ statusValue + "\")";
					tempCell.setCellFormula(linkFormula);
					FileOutputStream out = new FileOutputStream(new File(
							filePath));
					workbook.write(out);
					Thread.sleep(2000);
					out.close();

				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// return 0;
	}

	public static void selectDate(WebDriver driver, String Date)
			throws Exception {
		driver.findElement(
				By.xpath("//div[@class='x-form-field-wrap x-form-field-trigger-wrap']/input[contains(@name,'startDate')]/../img"))
				.click();
		String[] temp;
		String delimiter = "/";
		temp = Date.split(delimiter);

		switch (temp[0]) {
		case "01": {
			temp[0] = "Jan";
			break;
		}

		case "02": {
			temp[0] = "Feb";
			break;
		}

		case "03": {
			temp[0] = "Mar";
			break;
		}

		case "04": {
			temp[0] = "Apr";
			break;
		}

		case "05": {
			temp[0] = "May";
			break;
		}

		case "06": {
			temp[0] = "Jun";
			break;
		}

		case "07": {
			temp[0] = "Jul";
			break;
		}

		case "08": {
			temp[0] = "Aug";
			break;
		}

		case "09": {
			temp[0] = "Sep";
			break;
		}

		case "10": {
			temp[0] = "Oct";
			break;
		}

		case "11": {
			temp[0] = "Nov";
			break;
		}

		case "12": {
			temp[0] = "Dec";
			break;
		}

		default: {
			break;
		}
		}
		if (temp[1].startsWith("0")) {
			temp[1] = temp[1].replace("0", "");
		}
		driver.findElement(
				By.xpath("//table[@class='x-date-pickerplus']/tbody/tr/td/table/tbody/tr/td/em/button"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.linkText(temp[0])).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText(temp[2])).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(text(),'OK')]")).click();
		Thread.sleep(2000);

		if (driver.findElements(By.linkText(temp[1])).size() > 0) {
			if (driver.findElement(
					By.xpath("(//a/em/span[text()='" + temp[1] + "'])[2]"))
					.isEnabled())
				driver.findElement(
						(By.xpath("(//a/em/span[text()='" + temp[1] + "'])[2]")))
						.click();
		} else
			driver.findElement(By.linkText(temp[1])).click();
		Thread.sleep(2000);
	}

	public static void launch(WebDriver driver) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			Thread.sleep(2000);
			// Initializing the browser
			String baseUrl = Application_Utils.settings("url");
			driver.get(baseUrl);
			wait.pollingEvery(5, TimeUnit.SECONDS);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void waitWhileLoading(WebDriver driver1) {
		WebDriver driver = driver1;
		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.pollingEvery(1, TimeUnit.SECONDS);
		try {
			wait.until(ExpectedConditions.stalenessOf(driver.findElement(By
					.xpath("//div[contains(@class,'ext-el-mask-msg x-mask-loading')][0]"))));
		} catch (Exception e) {
		}
	}

	public static void login(WebDriver driver) {
		try {
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@name='username']")).sendKeys(
					"206447340");
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(
					"nbc@123nb");
			Thread.sleep(2000);
			driver.findElement(By.name("Submit")).sendKeys(Keys.ENTER);
			new WebDriverWait(driver, 60).until(ExpectedConditions
					.visibilityOf(driver.findElement(By
							.xpath("//a[@href='/CIR/dashboardPage']"))));
			new WebDriverWait(driver, 60).until(ExpectedConditions
					.elementToBeClickable(driver.findElement(By
							.xpath("//a[@href='/CIR/dashboardPage']"))));
			driver.findElement(By.xpath("//a[@href='/CIR/dashboardPage']"))
					.click();
			driver.switchTo().frame(0);
		} catch (Exception e) {
		}
	}

	public static List<WebElement> listOfElements(WebDriver driverObj,
			String className) {
		try {
			// listOfElements(driver,"button[text()='Export to']").get(0).click();
			// List<WebElement> formatTabTextBox =
			// driverObj.findElements(By.xpath("//*[contains(@class,'x-form-text x-form-field x-form-invalid')]"));
			List<WebElement> formatTabTextBox = driverObj.findElements(By
					.xpath("//*[" + className + "]"));
			List<WebElement> formatTabTextBoxVis = new ArrayList<WebElement>();
			for (WebElement e : formatTabTextBox) {
				if (e.isDisplayed()) {
					formatTabTextBoxVis.add(e);
				}
			}
			return formatTabTextBoxVis;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return null;
	}

	public static String settings(String columnName) {
		try {
			String result = null;
			FileInputStream file = new FileInputStream(new File(
					settingsFilePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			// XSSFSheet sheet = workbook.getSheetAt(workSheetNumber);
			XSSFSheet sheet = workbook.getSheetAt(0);
			Row row = sheet.getRow(0);

			String str1 = columnName;
			int columnNum = 0;
			for (int x = 0; x < row.getLastCellNum(); x++) {
				if ((str1.compareToIgnoreCase(row.getCell(x)
						.getStringCellValue())) == 0) {
					columnNum = x;
					break;
				}
			}

			row = sheet.getRow(1);
			Cell cell = row.getCell(columnNum);
			cell = row.getCell(columnNum);
			if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				// This cell is empty
				result = "";
			} else {
				// This cell has data in it
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					result = Integer.toString((int) cell.getNumericCellValue());
					break;
				case Cell.CELL_TYPE_STRING:
					result = cell.getStringCellValue();
					break;
				}
			}

			// int noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
			file.close();
			result = result.trim();
			return result;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return columnName;
	}

	public static int excelSheetCount(String sheetName) {
		try {
			// setReportName(sheetName);
			FileInputStream file = new FileInputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// XSSFSheet sheet = workbook.getSheetAt(0);
			// System.out.println("number of workbooks: "+workbook.getNumberOfSheets());

			int workSheetNum = 0;
			sheetName = sheetName.replaceAll("(^\\s*|\\s*$)", "");
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				// System.out.println(workbook.getSheetName(i));
				if (workbook.getSheetName(i).compareToIgnoreCase(sheetName) == 0) {
					workSheetNum = i;
					break;
				}
			}
			file.close();
			return workSheetNum;
		} catch (Exception e) {
		}
		int result = 0;
		return result;
	}

	public static int excelRowCount(int workSheetNumber) {
		int result = 0;
		try {
			FileInputStream file = new FileInputStream(new File(filePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(workSheetNumber);
			file.close();

			return sheet.getLastRowNum() + 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// e.printStackTrace();

		return result;
	}

	public static int excelColCount(String sheetName, String columnName) {
		try {
			FileInputStream file = new FileInputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			Row header = sheet.getRow(0);
			for (int c = 0; c < header.getLastCellNum(); c++) {
				if (header.getCell(c).getStringCellValue()
						.equalsIgnoreCase(columnName)) {
					return c;
				}
			}
			file.close();
			// return sheet.getLastRowNum()+1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		int result = 0;
		return result;
	}

	public static String excelText(int workSheetNumber, String columnName,
			int rowId) {
		try {
			String result = null;
			FileInputStream file = new FileInputStream(new File(filePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(workSheetNumber);
			Row row = sheet.getRow(0);

			String str1 = columnName;
			int columnNum = 0;
			for (int x = 0; x < row.getLastCellNum(); x++) {
				if ((str1.compareToIgnoreCase(row.getCell(x)
						.getStringCellValue())) == 0) {
					columnNum = x;
					break;
				}
			}
			row = sheet.getRow(rowId);
			Cell cell = row.getCell(columnNum);
			cell = row.getCell(columnNum);
			if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				// This cell is empty
				result = "";
			} else {
				// This cell has data in it
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					result = Integer.toString((int) cell.getNumericCellValue());
					break;
				case Cell.CELL_TYPE_STRING:
					result = cell.getStringCellValue();
					break;
				}
			}
			file.close();
			result = result.replaceAll("(^\\s*|\\s*$)", "");
			return result;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return columnName;
	}

	public static void excelWrite(String workSheet, String hdrColumn,
			String[] header, int rowIndex) {
		try {
			InputStream inp = new FileInputStream(filePath);
			// Workbook workbook = WorkbookFactory.create(inp);
			XSSFWorkbook workbook = new XSSFWorkbook(inp);
			XSSFSheet sheet = workbook.getSheet(workSheet);
			// CreationHelper factory = workbook.getCreationHelper();
			// Drawing drawing = sheet.createDrawingPatriarch();
			// ClientAnchor anchor = factory.createClientAnchor();

			for (int c1 = 0; c1 < workbook.getSheet(workSheet).getRow(0)
					.getLastCellNum(); c1++) {
				if (workbook.getSheet(workSheet).getRow(0).getCell(c1)
						.getStringCellValue().equalsIgnoreCase(hdrColumn)) {
					for (int i = 0; i < header.length; i++) {
						Row row = null;
						if (c1 == 0) {
							row = sheet.createRow(rowIndex++);
						} else {
							row = sheet.getRow(rowIndex++);
						}
						Cell cell0 = row.createCell(c1);
						cell0.setCellValue(header[i].trim());
						// Comment comment = drawing.createCellComment(anchor);
						// RichTextString str0 =
						// factory.createRichTextString(excelText(excelSheetCount("changenotice_sql"),
						// hdrColumn, r));
						// comment.setString(str0);
						// cell0.setCellComment(comment);
					}
				}
			}
			FileOutputStream fos = new FileOutputStream(filePath);
			workbook.write(fos);
			fos.close();
			// System.out.println(filePath + " written successfully");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void excelToWrite(String path, String workSheet,
			String hdrColumn, String[] header, int rowIndex) {
		try {
			InputStream inp = new FileInputStream(path);
			// Workbook workbook = WorkbookFactory.create(inp);
			XSSFWorkbook workbook = new XSSFWorkbook(inp);
			XSSFSheet sheet = workbook.getSheet(workSheet);
			// CreationHelper factory = workbook.getCreationHelper();
			// Drawing drawing = sheet.createDrawingPatriarch();
			// ClientAnchor anchor = factory.createClientAnchor();

			for (int c1 = 0; c1 < workbook.getSheet(workSheet).getRow(0)
					.getLastCellNum(); c1++) {
				if (workbook.getSheet(workSheet).getRow(0).getCell(c1)
						.getStringCellValue().equalsIgnoreCase(hdrColumn)) {
					for (int i = 0; i < header.length; i++) {
						Row row = null;
						if (c1 == 0) {
							row = sheet.createRow(rowIndex++);
						} else {
							row = sheet.getRow(rowIndex++);
						}
						Cell cell0 = row.createCell(c1);
						cell0.setCellValue(header[i].trim());
						// Comment comment = drawing.createCellComment(anchor);
						// RichTextString str0 =
						// factory.createRichTextString(excelText(excelSheetCount("changenotice_sql"),
						// hdrColumn, r));
						// comment.setString(str0);
						// cell0.setCellComment(comment);
					}
				}
			}
			FileOutputStream fos = new FileOutputStream(path);
			workbook.write(fos);
			fos.close();
			// System.out.println(filePath + " written successfully");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void excelUpdate() {
		try {
			// String filePath1 = "C://Test//test.xlsx";
			InputStream inp = new FileInputStream(filePath);
			// Workbook workbook = WorkbookFactory.create(inp);
			XSSFWorkbook workbook = new XSSFWorkbook(inp);
			XSSFSheet sheet = workbook.getSheet(reportName);

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				sheet.removeRow(sheet.getRow(i));
			}
			OutputStream out = new FileOutputStream(filePath);
			workbook.write(out);
			out.flush();
			out.close();

			for (int r = 1; r <= workbook.getSheet(reportName + "_sql")
					.getLastRowNum(); r++) {
				// if (excelText(excelSheetCount(reportName+"_sql"),
				// "lastupdated", r).equalsIgnoreCase("")){

				int rowIndexInitial = excelRowCount(excelSheetCount(reportName));// workbook.getSheet("changenotice").getLastRowNum()+1;
				for (int c = 0; c < workbook.getSheet(reportName + "_sql")
						.getRow(0).getLastCellNum(); c++) {

					String db_header = "";
					String hdrColumn = workbook.getSheet(reportName + "_sql")
							.getRow(0).getCell(c).getStringCellValue();
					// System.out.println("sql row: "+r+" col : "+c+" " +
					// hdrColumn);

					if (excelText(excelSheetCount(reportName + "_sql"),
							hdrColumn, r).toLowerCase().contains("select ")) {
						db_header = connectDB(excelText(
								excelSheetCount(reportName + "_sql"),
								hdrColumn, r));
						// System.out.println(db_header);
						String[] header = db_header.split(";");
						int rowIndex = rowIndexInitial;
						// System.out.println(excelRowCount(excelSheetCount(reportName)));
						excelWrite(reportName, hdrColumn, header, rowIndex);
					}

					else {
						// System.out.println(hdrColumn+
						// " : "+(excelRowCount(excelSheetCount("changenotice"))-rowIndexInitial)+" Value: "+excelText(excelSheetCount("changenotice_sql"),
						// hdrColumn, r));
						String[] header = new String[excelRowCount(excelSheetCount(reportName))
								- rowIndexInitial];

						for (int i = 0; i < header.length; i++) {
							header[i] = excelText(excelSheetCount(reportName
									+ "_sql"), hdrColumn, r);
						}
						int rowIndex = rowIndexInitial;
						excelWrite(reportName, hdrColumn, header, rowIndex);
					}
				}

				// System.out.println(new
				// SimpleDateFormat("ddMMMyyyy_HHmmss").format(System.currentTimeMillis()));
				String[] lastUpdateValue = { connectDB(
						settings("servicepackquery")).replace(";", "")
						+ "_"
						+ new SimpleDateFormat("ddMMMyyyy_HHmmss")
								.format(System.currentTimeMillis()) };
				// int rowIndex = rowIndexInitial;
				// System.out.println(excelRowCount(excelSheetCount(reportName)));
				excelWrite(reportName + "_sql", "lastupdated", lastUpdateValue,
						r);
				// }
			}
			System.out.println("File Updated..");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void moveFiles(String patchFolderName, int i) {
		try {
			// Thread.sleep(7000);
			String patchFolder = "//" + patchFolderName;
			String targetFolder = settings("reportfolder");
			// String defaultFolder = settings("downloadfolder");
			String defaultFolder = System.getProperty("user.home")
					+ "\\Downloads";
			File dirSource = new File(defaultFolder);
			File dirTarget = new File(targetFolder + patchFolder);

			if (!dirTarget.exists()) {
				dirTarget.mkdir();
				System.out.println(dirTarget.getAbsolutePath());
			}

			for (File file : dirSource.listFiles()) {

				if (file.getName().endsWith((".xls"))) {
					File source = new File(defaultFolder + "//"
							+ file.getName());
					Date creationDate = new Date(source.lastModified());
					DateFormat df = new SimpleDateFormat("ddMMMyyyy_HHmmss");// H:24
																				// hrs,
																				// h:
																				// 12hrs

					String fileName = file.getName();
					fileName = fileName.replaceAll("[^a-zA-z]", "");
					fileName = fileName.replace("xls", "");
					// System.out.println(defaultFolder+patchFolder+"//"+fileName+"_"+df.format(creationDate)+".xls");
					File destination = new File(dirTarget + "//" + fileName
							+ "_" + df.format(creationDate) + "_" + i + "_"
							+ patchFolderName + ".xls");
					// File destination = new
					// File(defaultFolder+patchFolder+"//"+fileName+"_"+patchFolderName+"_"+i+".xls");
					if (!destination.exists()) {
						// && (!destination.getAbsolutePath().matches(fileName +
						// "_".*.+ i)
						source.renameTo(destination);
						System.out.println(destination.getAbsolutePath());
					}
				}

				if (file.getName().endsWith((".pdf"))) {
					File source = new File(defaultFolder + "//"
							+ file.getName());
					Date creationDate = new Date(source.lastModified());
					DateFormat df = new SimpleDateFormat("ddMMMyyyy_HHmmss");// H:24
																				// hrs,
																				// h:
																				// 12hrs

					String fileName = file.getName();
					fileName = fileName.replaceAll("[^a-zA-z]", "");
					fileName = fileName.replace("pdf", "");
					// System.out.println(defaultFolder+patchFolder+"//"+fileName+"_"+df.format(creationDate)+".xls");
					File destination = new File(dirTarget + "//" + fileName
							+ "_" + df.format(creationDate) + "_" + i + "_"
							+ patchFolderName + ".pdf");
					// File destination = new
					// File(defaultFolder+patchFolder+"//"+fileName+"_"+patchFolderName+"_"+i+".xls");
					if (!destination.exists()) {
						source.renameTo(destination);
						System.out.println(destination.getAbsolutePath());
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static String connectDB(String sqlQuery) {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			// URL of Oracle database server
			// String url =
			// "jdbc:oracle:thin:@usnycdbsq026.nbcuni.ge.com:15196:D124";
			// String url = "jdbc:oracle:thin:@"+ settings("dbserver")+ ":" +
			// settings("dbport")+ ":" + settings("dbsid");
			String url = "jdbc:oracle:thin:@//" + settings("dbserver") + ":"
					+ settings("dbport") + "/" + settings("dbsid");
			// jdbc:oracle:thin:@//aoadbss00002c0.tfayd.com:15192/G123
			// properties for creating connection to Oracle database
			Properties props = new Properties();
			props.setProperty("user", settings("dbusername"));
			props.setProperty("password", settings("dbpassword"));
			// creating connection to Oracle database using JDBC
			Connection conn = DriverManager.getConnection(url, props);

			// String sql =
			// "select service_pack_number FROM ONAIR.PATCH_DELIVERY where patch_date in (Select max(patch_date) FROM ONAIR.PATCH_DELIVERY)";
			// String sql = sqlQuery;
			Statement s = conn.createStatement();

			// ResultSet result = s.executeQuery(sql);
			ResultSet result = s.executeQuery(sqlQuery);
			String servicePackNum = new String();
			servicePackNum = "";

			while (result.next()) {
				servicePackNum = servicePackNum + result.getString(1) + ";";
			}
			/*
			 * while (result.next()) { servicePackNum =
			 * result.getString("plan_id"); }
			 */
			conn.close();
			s.close();
			return servicePackNum;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		String test = "DB_Error";
		return test;
	}

//	public static void checkItemInSelect(WebDriver driver, String fieldLabel,
//			String values) {
//		try {
//			// driver.findElement(By.xpath("//span[text()='"+fieldLabel+"']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]")).click();
//			// span[text()='Pressure']/../../div/div/img
//			driver.findElement(
//					By.xpath("//span[text()='" + fieldLabel
//							+ "']/../../div/div/img")).click();
//			Thread.sleep(3000);
//			String items = values;// "F12-14;F25-34";
//			String[] item = items.split(";");
//			for (int j = 0; j < item.length; j++) {
//				listOfElements(
//						driver,
//						"contains(@class,'ux-lovcombo-item-text') and text()='"
//								+ item[j].trim() + "'").get(0).click();
//				// listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).isDisplayed();
//			}
//			driver.findElement(
//					By.xpath("//span[text()='" + fieldLabel
//							+ "']/../../div/div/img")).click();
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.out.println("error in selecting multiple values");
//		}
//	}
	
	public static void checkItemInSelect(WebDriver driver,String fieldLabel,String values){		
		try{
			//driver.findElement(By.xpath("//span[text()='"+fieldLabel+"']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]")).click();
			//span[text()='Pressure']/../../div/div/img
			driver.findElement(By.xpath("//span[text()='"+fieldLabel+"']/../../div/div/img")).click();
			Thread.sleep(3000);
			String items = values;//"F12-14;F25-34";
			System.out.println(values + " are the values");
			String[] item = items.split(";");
			for (int j=0;j<item.length;j++){
				listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).click();		
				//listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).isDisplayed();
			}
			driver.findElement(By.xpath("//span[text()='"+fieldLabel+"']/../../div/div/img")).click();
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("error in selecting multiple values");
			}
	}

	public static void checkItemNotSelect(WebDriver driver, String fieldLabel,
			String values) {
		try {
			driver.findElement(
					By.xpath("//span[text()='"
							+ fieldLabel
							+ "']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]"))
					.click();
			Thread.sleep(3000);
			String items = values;// "F12-14;F25-34";
			String[] item = items.split(";");
			for (int j = 0; j < item.length; j++) {
				try {
					// if(listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).isDisplayed())
					if (listOfElements(
							driver,
							"contains(@class,'x-combo-list-item') and text()='"
									+ item[j].trim() + "'").get(0)
							.isDisplayed())
						Assert.fail("Value " + item
								+ " is available in the field " + fieldLabel
								+ "");
				} catch (Exception e) {
					System.out.println("");
				}
			}
			// driver.findElement(By.xpath("//span[text()='"+fieldLabel+"']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]")).click();
		} catch (Exception e) {
			System.out.println("");
		}
	}

	public static void checkItemExistence(WebDriver driver, String fieldLabel,
			String values) {
		try {
			driver.findElement(
					By.xpath("//span[text()='"
							+ fieldLabel
							+ "']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]"))
					.click();
			Thread.sleep(3000);
			String items = values;// "F12-14;F25-34";
			String[] item = items.split(";");

			for (int j = 0; j < item.length; j++) {
				// if(listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).isDisplayed())
				try {
					if (!listOfElements(
							driver,
							"contains(@class,'x-combo-list-item') and text()='"
									+ item[j].trim() + "'").get(0)
							.isDisplayed())
						System.out.println("Value " + item
								+ " is available in the field " + fieldLabel
								+ "");
				} catch (Exception e) {
					System.out.println("");
				}
			}
		} catch (Exception e) {
			System.out.println("");
		}
	}

	// boolean match = true;
	// int j=0;
	// driver.findElement(By.xpath("//span[text()='"+fieldSet+"']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]")).click();
	// Thread.sleep(3000);
	// String demos = values;//"F12-14;F25-34";
	// String[] demo = demos.split(";");
	//
	// //
	// listOfElements(driver,"contains(@class,'ux-lovcombo-item-text') and text()='"+item[j].trim()+"'").get(0).click();
	// //
	// String
	// x=driver.findElement(By.xpath("//span[text()='Breakdown']/following::div[contains(@class,'x-combo-list-inner')]/div[contains(@class,'x-combo-list-item')]")).getText();
	// System.out.println("x="+x);
	// List<WebElement> rows =
	// driver.findElements(By.xpath("//span[text()='Breakdown']/following::div[contains(@class,'x-combo-list-inner')]/div"));
	// for (WebElement row : rows)
	// {
	// String tValue = row.getText();
	//
	// System.out.println("itemsAppln[j]="+tValue);
	// System.out.println("demo[j]="+demo[j]);
	// if(!tValue.equals(demo[j])){
	// match = false;
	// }
	//
	// j++;
	// }
	// return match;
	// }
	// catch(Exception
	// e){System.out.println("error in selecting multiple values");}
	// return null;
	// }
	// }
	//

	public static void checkAllItemsUncheck(WebDriver driver, String fieldLabel) {
		try {
			driver.findElement(
					By.xpath("//span[text()='"
							+ fieldLabel
							+ "']/following::img[contains(@class,'x-form-trigger x-form-arrow-trigger')]"))
					.click();
			int count = driver
					.findElements(
							By.xpath("//*[@class='x-combo-list-item x-combo-selected']/img"))
					.size();
			for (int j = 2; j <= count; j++) {
				try {
					System.out
							.println("(//span[text()='"
									+ fieldLabel
									+ "']/following::div[contains(@class,'x-combo-list-item')]/img)["
									+ j + "]");
					if (driver
							.findElement(
									By.xpath("(//span[text()='"
											+ fieldLabel
											+ "']/following::div[contains(@class,'x-combo-list-item')]/img)["
											+ j + "]")).isSelected())
						Assert.fail("Checkbox number " + j + "is checked");
				} catch (Exception e) {
					e.getMessage();
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public static void moveToRight(WebDriver driver, String values,
			String fieldSet) {
		try {
			driver.findElement(
					By.xpath("//span[text()='" + fieldSet
							+ "']/following::img[contains(@src,'none.gif')]"))
					.click();
			String demos = values;// "F12-14;F25-34";
			String[] demo = demos.split(";");

			for (int j = 0; j < demo.length; j++) {
				driver.findElement(
						By.xpath("//span[text()='"
								+ fieldSet
								+ "']/following::span[text()='Filter by Name']/following::input[contains(@class,'x-form-text x-form-field')]"))
						.sendKeys(demo[j].trim());
				// waitWhileLoading(driver);
				Thread.sleep(3000);
				try {
					// System.out.println("//span[text()='"+fieldSet+"']/following::span[text()='"+demo[j].trim()+"']");
					// int
					// count=driver.findElements(By.xpath("//span[text()='"+fieldSet+"']/following::span[text()='"+demo[j].trim()+"']")).size();
					// System.out.println("count="+count);
					if (driver.findElements(
							By.xpath("//span[text()='" + fieldSet
									+ "']/following::span[text()='"
									+ demo[j].trim() + "']")).size() > 0) {
						// driver.findElement(By.xpath("//span[text()='"+fieldSet+"']/following::span[text()='"+demo[j].trim()+"']")).sendKeys(Keys.ENTER);
						Actions test = new Actions(driver);
						Action mouseHover = test.doubleClick(
								driver.findElement(By.xpath("//span[text()='"
										+ fieldSet
										+ "']/following::span[text()='"
										+ demo[j].trim() + "']"))).build();
						mouseHover.perform();
					}
					driver.findElement(
							By.xpath("//span[text()='"
									+ fieldSet
									+ "']/following::span[text()='Filter by Name']/following::input[contains(@class,'x-form-text x-form-field')]"))
							.clear();
				} catch (Exception e) {
					driver.findElement(
							By.xpath("//span[text()='"
									+ fieldSet
									+ "']/following::span[text()='Filter by Name']/following::input[contains(@class,'x-form-text x-form-field')]"))
							.clear();
				}
			}
		} catch (Exception e) {
			System.out.println("error in selecting multiple values");
		}
	}

	public static void validateReportGeneration(WebDriver driver, int i) {
		// i:Iteration Number

		try {
			// System.out.println("\n");
			int minimise = 0;

			// Waiting for report to generate
			// Getting count of jobs completed successfully
			List<WebElement> completedJobs = Application_Utils.listOfElements(
					driver, "contains(@class,'x-btn-text icon_job_completed')");
			int totalReports = Integer.parseInt(completedJobs.get(0).getText());

			// Getting count of jobs aborted
			List<WebElement> abortedJobs = Application_Utils.listOfElements(
					driver, "contains(@class,'x-btn-text icon_job_aborted')");
			int abortedReports = Integer.parseInt(abortedJobs.get(0).getText());

			// Checking if error message is displayed
			Thread.sleep(3000);

			if (Application_Utils.listOfElements(driver,
					"contains(@class,'x-tool x-tool-close')").size() > 0) {
				Application_Utils
						.listOfElements(driver,
								"contains(@class,'x-tool x-tool-close')")
						.get(0).click();
				System.out.println("*******************Row " + i
						+ " : Report was not generated*******************\n");
			}

			else {
				while ((totalReports == Integer.parseInt(completedJobs.get(0)
						.getText()))
						&& (abortedReports == Integer.parseInt(abortedJobs.get(
								0).getText()))) {
				}

				if (totalReports + 1 == Integer.parseInt(completedJobs.get(0)
						.getText())) {
					complete++;
					System.out.println("Row " + i + " : Report "
							+ Integer.parseInt(completedJobs.get(0).getText())
							+ " generated at " + new Date());
					minimise = minimise + 1;
					if (minimise == 1) {
						Robot r;
						try {
							r = new Robot();
							Thread.sleep(1000);
							r.keyPress(KeyEvent.VK_ALT);
							r.keyPress(KeyEvent.VK_SPACE);
							Thread.sleep(1000);
							r.keyPress(KeyEvent.VK_N);
							r.keyRelease(KeyEvent.VK_ALT);
							r.keyRelease(KeyEvent.VK_SPACE);
						} catch (AWTException e) {
							System.out.println("Error while minimising");
						}
						minimise = minimise + 1;
					}
				}
				if (abortedReports + 1 == Integer.parseInt(abortedJobs.get(0)
						.getText())) {

					// -------------------------------------------------------------
					String[] status = { "Error" };
					Application_Utils.excelWrite(reportName, "status", status,
							i);
					// -------------------------------------------------------------
					System.out.println("Row " + i + " : Report "
							+ Integer.parseInt(abortedJobs.get(0).getText())
							+ " sent to error queue at " + new Date());
				} else {
					Thread.sleep(5000);
					// driver.navigate().refresh();

					// Fetching the service pack number
					String servicePackNumber = Application_Utils
							.connectDB(Application_Utils
									.settings("servicepackquery"));
					// Moving files to sub-folder
					Application_Utils.moveFiles(
							servicePackNumber.replaceAll(";", ""), i);
					String[] status = { "complete" };
					// Application_Utils.excelWrite(sheetName,"status", status,
					// i);

					Application_Utils.excelWrite(reportName, "status", status,
							i);
				}
			}
			// System.out.println("excelRowCount(0)-1)="+(excelRowCount(0)-1));
			// System.out.println("complete="+complete);
			/*
			 * if(complete==(excelRowCount(0)-1)) {
			 * System.out.println("Report "+
			 * reportName.toUpperCase()+"'s all the iterations are pass\n"); }
			 */
			// System.out.println("\n");
		} catch (Exception e) {
			System.out.println("error in report generation");
		}
	}

	public static void charType(WebDriver driver, String labelName, String str) {
		String x = str;
		char[] xh = new char[x.length()];
		for (int i = 0; i < x.length(); i++) {
			xh[i] = x.charAt(i);
			String ih = Character.toString(xh[i]);
			driver.findElement(By.xpath(labelName)).sendKeys(ih);
		}
	}

	public static String getExcelValue(Sheet worksheet, int rowNumber,
			int columnNumber) {
		// getting row based on the row number
		Row tempRow = worksheet.getRow(rowNumber);
		// if row number is null
		if (tempRow == null) {
			// creating row in the excel sheet.
			tempRow = worksheet.createRow(rowNumber);
		}
		// getting the cell based on the column number
		Cell tempCell = tempRow.getCell(columnNumber);
		// if cell value is null
		if (tempCell == null) {
			// Creating cell in the excel sheet.
			tempCell = tempRow.createCell(columnNumber);
		}
		tempCell.setCellType(1);

		return tempCell.getStringCellValue();

	}

	public static String getCurrentTimeStamp() {
		SimpleDateFormat sdfDate = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");// dd/MM/yyyy
		Date now = new Date();
		String strDate = sdfDate.format(now);
		return strDate;
	}

	public static void getStartTime() {
		execStartTime = getCurrentTimeStamp();
		// System.out.println("execStartTime="+execStartTime);
	}

	public static long getTimeLapsed() {
		execEndTime = getCurrentTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = format.parse(execStartTime);
			d2 = format.parse(execEndTime);
			// System.out.println("execEndTime="+execEndTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long min = ((d2.getTime() - d1.getTime()) / (60 * 1000) % 60);
		long sec = min % 60;
		System.out.println(min + " minute");
		System.out.println(sec + " second");
		execStartTime = "";
		execEndTime = "";
		return ((d2.getTime() - d1.getTime()) / (60 * 1000) % 60);
	}
	/*
	 * public void selectDropDownValue(String locator, String option) {
	 * List<WebElement> AllCheckBoxes =
	 * WebElement.FindElements(By.xpath("//label/input")); // Get the count of
	 * check boxes int RowCount =
	 * WebElement.FindElements(By.XPath("//label/input")).Count; for (int i = 0;
	 * i < RowCount; i++) { // Check the check boxes based on index
	 * AllCheckBoxes[i].Click();
	 * 
	 * } Console.WriteLine(RowCount); }
	 */

	// public void selectDropDownValue(String locator, String option)
	// {
	//
	// List<WebElement>allOptions =driver.findElements(By.tagName("option"));
	// if(allOptions.size()>0){
	// WebElement txtBox=allOptions.get(0);
	// //((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute('value', '"+option+"');'txtBox);"javascript_click(txtBox);
	// String name = (String) ((JavascriptExecutor)
	// driver).executeScript("return arguments[0].tagName", option);
	// }
	// else
	// {
	// System.out.println("Element not found");
	// }
	//
	// }

}
/*
 * Long waitfor = System.currentTimeMillis(); Boolean checkAgain = false; while
 * (checkAgain == true || System.currentTimeMillis() <= waitfor+4000) { try{ for
 * (WebElement e : driver.findElements(By.xpath(
 * "//div[contains(@class,'ext-el-mask-msg x-mask-loading')]"))) { if
 * (e.isDisplayed()) { checkAgain = true; waitfor = System.currentTimeMillis();
 * break; }else{ checkAgain = false; } } } catch(Exception e){ checkAgain =
 * false; } }
 */
