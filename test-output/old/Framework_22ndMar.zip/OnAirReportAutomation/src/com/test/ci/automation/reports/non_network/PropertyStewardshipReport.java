package com.test.ci.automation.reports.non_network;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.PropertyStewardshipScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class PropertyStewardshipReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException,
	IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");

		String[] tabs = { "General", "Plan Data", "Formatting" };
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {

			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config
					.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber,
						"RunMode", i).equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber,
								"RunMode", i).equalsIgnoreCase("No")) {
					/**
					 * this will not execute the test case
					 */
				} else {
					try {
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());
						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Property Stewardship Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Property Stewardship Report"))));
						driver.findElement(By.linkText("Property Stewardship Report")).click();
						System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
						Thread.sleep(2000);

						// Clear form
						driver.findElement(By.xpath("//*[contains(@class,'x-btn-text icon_clear')]")).click();
						Thread.sleep(5000);

						// Clicking the "General" Tab
						driver.findElement(By.linkText("" + tabs[0] + "")).click();
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i))))
							Log.error("Property is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));

						if (ReadWriteTestDataSheet.excelText(sheetNumber, "property", i).equalsIgnoreCase("NBC")){
							driver.findElement(By.xpath("//span[text()='Division']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "division", i));
							driver.findElement(By.xpath("//span[text()='Division']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
							Thread.sleep(2000);
							if (!(driver.findElement(By.xpath("//span[text()='Division']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "division", i))))
								Log.error("Division is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "division", i));
						}
						
						
						driver.findElement(By.xpath("//span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "reporttype", i));
						Thread.sleep(4000);
						driver.findElement(By.xpath("//span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(4000);
						if (!(driver.findElement(By.xpath("//span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "reporttype", i))))
							Log.error("Report Type is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "reporttype", i));

						if (driver.findElement(By.xpath("//span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals("Selected Quarter")) {
							driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
							Thread.sleep(2000);
							driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,"startdate", i));
							driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
							Thread.sleep(2000);
							if (!(driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i))))
								Log.error("Start Date is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i));
						}
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i));
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i))))
							Log.error("End Date is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i));


						// Clicking the "Plan Data" Tab
						driver.findElement(By.linkText("" + tabs[1] + "")).click();
						Thread.sleep(3000);
						/*Application_Utils.checkItemInSelect(driver,"Guaranteed Status", ReadWriteTestDataSheet.excelText(sheetNumber,"guaranteedstatus", i));
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Guaranteed Status']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "guaranteedstatus", i))))
							Log.error("Guaranteed Status is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "guaranteedstatus", i));*/

						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber,"planclass", i), "Plan Class");

						//Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber,"advertiser", i), "Advertiser");

						Application_Utils.checkItemInSelect(driver,"Plan Status",ReadWriteTestDataSheet.excelText(sheetNumber,"planstatus", i));
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Plan Status']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "planstatus", i))))
							Log.error("Plan Status is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "planstatus", i));

						if (!ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i).equals(""))
						{
							System.out.println(ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i));
							Application_Utils.checkItemInSelect(driver,"Plan Sub Status", ReadWriteTestDataSheet.excelText(sheetNumber,"plansubstatus", i));
							Thread.sleep(2000);
							if (!(driver.findElement(By.xpath("//span[text()='Plan Sub Status']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i))))
								Log.error("Plan Sub Status is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i));
						}
						// Clicking the "Formatting" Tab
						driver.findElement(By.linkText("" + tabs[2] + ""))
						.click();
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Plan Summary']/following::a[contains(@class,'xcheckbox-off')]")).click();
						Thread.sleep(4000);
						if (!driver.findElement(By.xpath("//span[text()='Plan Summary']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on"))
							Log.error("Plan Summary is not \"CHECKED\"");

						driver.findElement(By.xpath("//span[text()='Guaranteed']/following::a[contains(@class,'xcheckbox-off')]")).click();
						Thread.sleep(4000);
						if (!(driver.findElement(By.xpath("//span[text()='Guaranteed']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on")))
							Log.error("Guaranteed is not \"CHECKED\"");

						driver.findElement(By.xpath("//span[text()='Actual & Projected']/following::a[contains(@class,'xcheckbox-off')]")).click();
						Thread.sleep(4000);
						if (!(driver.findElement(By.xpath("//span[text()='Actual & Projected']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on")))
							Log.error("Actual & Projected is not \"CHECKED\"");

						driver.findElement(By.xpath("//span[text()='Summary']/following::a[contains(@class,'xcheckbox-off')]")).click();
						Thread.sleep(4000);
						if (!(driver.findElement(By.xpath("//span[text()='Summary']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on")))
							Log.error("Summary is not \"CHECKED\"");

						Application_Utils.checkItemInSelect(driver,"Additional Details",ReadWriteTestDataSheet.excelText(sheetNumber,"additionaldetails", i));
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Additional Details']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "additionaldetails", i))))
							Log.error("Additional Details is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "additionaldetails", i));


						if (ReadWriteTestDataSheet.excelText(sheetNumber, "quarterlydetail", i).equalsIgnoreCase("Yes")){
							driver.findElement(By.xpath("//span[text()='Quarterly Detail']/following::a[contains(@class,'xcheckbox-off')]")).click();
							Thread.sleep(4000);
							if (!(driver.findElement(By.xpath("//span[text()='Quarterly Detail']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on")))
								Log.error("Quarterly Detail is not \"CHECKED\"");
						}

						if (ReadWriteTestDataSheet.excelText(sheetNumber, "planlinkdetail", i).equalsIgnoreCase("Yes")){
							driver.findElement(By.xpath("//span[text()='Plan Link Detail']/following::a[contains(@class,'xcheckbox-off')]")).click();
							Thread.sleep(4000);
							if (!(driver.findElement(By.xpath("//span[text()='Plan Link Detail']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains("xcheckbox-on")))
								Log.error("Plan Link Detail is not \"CHECKED\"");
						}

						driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,"groupby", i));
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "groupby", i))))
							Log.error("Group By is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "groupby", i));

						driver.findElement(By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber,"primarysortby", i));
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						if (!(driver.findElement(By.xpath("//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "primarysortby", i))))
							Log.error("Primary Sort By is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "primarysortby", i));

						clickOnFilterCriteriaCheckBox();	
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
							Log.error("Filter Criteria checkbox is not checked");
						exportReport("Formatted Excel");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}