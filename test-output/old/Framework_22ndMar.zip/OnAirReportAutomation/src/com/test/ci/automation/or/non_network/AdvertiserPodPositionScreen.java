package com.test.ci.automation.or.non_network;

public class AdvertiserPodPositionScreen {
	
	public static final String ADVERTISERPODPOSITIONREPORT = "linkText =Advertiser Pod Position Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath =//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath =//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath =//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ADVERTISER = "xpath =//span[text()='advertiser']/following::img[contains(@src,'none.gif')]";
	public static final String COMMERCIALTYPE = "xpath =//span[text()='commercialtype']/following::img[contains(@src,'none.gif')]";
	public static final String COMMERCIALTYPEGROUP = "xpath =//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";
	
	

}
