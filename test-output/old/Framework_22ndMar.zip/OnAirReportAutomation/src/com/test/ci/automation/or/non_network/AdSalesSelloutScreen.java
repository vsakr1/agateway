package com.test.ci.automation.or.non_network;

public class AdSalesSelloutScreen {
	//public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	//public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	
	public static final String ADSALESSELLOUTREPORT = "linktext=Ad Sales Sellout Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath=//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANDATA = "";
	//planclass
	public static final String SPOTDATA = "";
	public static final String COMMERCIALTYPEGROUP = "xpath =//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	//commercialtypegroup
	public static final String SELLINGNAME = "";
	//daypart
	public static final String FORMATTING = "";
	//path("//span[text()='"+fieldLabel+"']/../../div/div/img")
	//planstatus
	public static final String SOLD = "xpath =//span[text()='Sold']/../../div/div/input[@type='text']";
	public static final String OTHER = "xpath =//span[text()='Other']/../../div/div/input[@type='text']";
	public static final String PRESSURE = "xpath//span[text()='Pressure']/../../div/div/input[@type='text']";
	public static final String DAYPARTGROUPING = "xpath =//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPARTSUMMARY = "xpath =//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";
	
}
	
	