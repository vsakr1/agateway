package com.test.ci.automation.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Reporter;

import com.test.ci.automation.scripts.BaseScripts;

public class TestDataProvider extends BaseScripts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		HashMap<String, String> oneRowStepData = new HashMap();
//		oneRowStepData.put("pne", "87878");
//		oneRowStepData.put("2", "776677");
//		oneRowStepData.put("3", "kkjkj");
//		oneRowStepData.put("4", "kkjkj");
//		oneRowStepData.put("5", "kkjkj");
//		oneRowStepData.put("6", "");
//		oneRowStepData.put("7", "");
//
//		for (Map.Entry<String, String> entry : oneRowStepData.entrySet()) {
//		    String key = entry.getKey();
//		    Object value = entry.getValue();
//		    System.out.println(key +"   "+ value);
//		    // ...
//		}
		
		try {
			 List<HashMap<String, String>> testData = getTestDataInfo("C:\\dev\\log\\commercialformat - Copy (3).xlsx");
			 System.out.println(testData.size());
				Object[][] testCaseSuite = new String[testData.size()][];
				for (int i = 0; i < testData.size(); i++) {
					HashMap<String, String> h = testData.get(i);
					System.out.println(h + " hey its h");
				}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static List<HashMap<String, String>> getTestDataInfo(
			String testDataPath) throws IOException {
		List<HashMap<String, String>> completeTestDataInList = new ArrayList<HashMap<String, String>>();
		InputStream ExcelFileToRead = new FileInputStream(testDataPath);
		XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);

		XSSFWorkbook test = new XSSFWorkbook();

		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row;
		XSSFCell cell;
		Iterator rows = sheet.rowIterator();

		int numberofrow = sheet.getPhysicalNumberOfRows();
		int numberofcol = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println(numberofcol + " is the colomn " + numberofrow
				+ " number of row ");

		for (int rowNum = 1; rowNum < numberofrow; rowNum++) {
			HashMap<String, String> oneRowStepData = new HashMap();
			/**
			 * code based on name
			 */
			for (int colName = 0; colName < numberofcol; colName++) {
				if (sheet.getRow(rowNum).getCell(colName) != null) {
					oneRowStepData.put(sheet.getRow(0).getCell(colName)
							.getStringCellValue(), sheet.getRow(rowNum)
							.getCell(colName).getStringCellValue());
//					System.out.println(sheet.getRow(0).getCell(colName)
//							.getStringCellValue()
//							+ " first");
//					System.out.println(sheet.getRow(rowNum).getCell(colName)
//							.getStringCellValue()
//							+ " first");
				} else {
					System.out.println("inside null");
					oneRowStepData.put(sheet.getRow(0).getCell(colName)
							.getStringCellValue(), "");

//					System.out.println(sheet.getRow(0).getCell(colName)
//							.getStringCellValue()
//							+ " first");
//					System.out.println(sheet.getRow(rowNum).getCell(colName)
//							.getStringCellValue()
//							+ " first");
				}

			}

			completeTestDataInList.add(oneRowStepData);
		}

		return completeTestDataInList;

	}
}
