package com.test.ci.automation.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.test.ci.automation.common.FileDownloaderUtility;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class GeneratePostRunReportsScript extends BaseScripts {
	@Test
	public void runPostRunReport() {
		try {
			boolean downLoadStatus = false;
			String sheetName = config.get("TestData.sheetName");
			launchApplicationByEnvironment(config.get("ENV"));
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			WebDriverWait waitForPageLoad = new WebDriverWait(driver, 10);
			;
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
					.linkText("Commercial Format Report"))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
					.cssSelector("button.icon_job_all"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver
					.findElement(By.cssSelector("button.icon_job_all"))));
			driver.findElement(By.cssSelector("button.icon_job_all")).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
					.cssSelector("div.x-window"))));
			int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config
					.get("TestData.sheetName")); i = i + 1) {
				if (ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i)
						.equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber,
								"RunMode", i).equalsIgnoreCase("No")) {
					/**
					 * this will not execute the test case
					 */
				} else {
					Application_Utils.getStartTime();
					String startTimeIs = Formatter.getTimeStamp();
					driver.findElement(By.cssSelector("button.icon_job_all"))
							.click();
					Thread.sleep(3000);
					driver.findElement(By.name("jobSearch")).clear();
					Thread.sleep(5000);
					String jobId = ReadWriteTestDataSheet.excelText(
							sheetNumber, "Pre_Run_JobId", i);
					driver.findElement(By.name("jobSearch")).sendKeys(jobId);
					driver.findElement(
							By.cssSelector("img.x-form-search-trigger"))
							.click();
					Thread.sleep(3000);
					wait.until(ExpectedConditions.visibilityOf(driver
							.findElement(By.cssSelector("div.x-grid3-col-id"))));
					String jobRunRow = "div.x-grid3-col-id";
					String jobRunRow1 = "td.x-grid3-td-id";
					String jobRunRow2 = "td.x-selectable";
					// String jobRunRow4 = "td.x-grid3-cell-first";

					System.out.println(driver.findElement(
							By.cssSelector(jobRunRow)).getText()
							+ "   first");
					System.out.println(driver.findElement(
							By.cssSelector(jobRunRow1)).getText()
							+ "   second");
					System.out.println(driver.findElement(
							By.cssSelector(jobRunRow2)).getText()
							+ "   three");
					// System.out.println(driver.findElement(By.cssSelector(jobRunRow4)).getText()
					// + "   four" );
					Actions action = new Actions(driver);
					driver.findElement(By.cssSelector(jobRunRow)).click();
					// driver.findElement(By.cssSelector(jobRunRow1)).click();

					action.moveToElement(
							driver.findElement(By.cssSelector(jobRunRow)))
							.doubleClick().build().perform();
					// action.moveToElement(driver.findElement(By.cssSelector(jobRunRow1))).doubleClick().build().perform();
					// action.moveToElement(driver.findElement(By.cssSelector(jobRunRow2))).doubleClick().build().perform();
					waitForPageLoad.until(ExpectedConditions
							.invisibilityOfElementLocated(By
									.cssSelector("div.x-mask-loading")));
					/*// Formatting tab
					if (ReadWriteTestDataSheet.excelText(sheetNumber, "optionalcolumns", i).equalsIgnoreCase("CPM")||ReadWriteTestDataSheet.excelText(sheetNumber, "optionalcolumns", i).equalsIgnoreCase("Select All"))
					{
						driver.findElement(By.linkText("Formatting")).click();
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "demo", i));
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(3000);
					}*/
					Thread.sleep(7000);
					System.out.println("about to click excel");
					exportReport("Formatted Excel");
					// driver.findElement(By.cssSelector("em.x-btn-arrow"));
					// System.out.println("about to click excel export");
					// //
					// driver.findElement(By.linkText(linkText)Text("Excel Formatted")).click();
					//
					// driver.findElement(By.cssSelector("a.x-menu-item[span=Excel Formatted]"));
					//
					// System.out.println("about to click excel unformate export");
					// // Application_Utils
					// // .listOfElements(driver,
					// // "button[text()='Export to PDF']").get(0)
					// // .click();

					/**
					 * code commented
					 */

					Thread.sleep(3000);

					/**
					 * New code starts here
					 */
					String jobNumber = null;
					jobNumber = getJobNumber();
					JOBID.add(jobNumber);

					updateJobNumberToTestDataSheetForPostRun(jobNumber, i);
					/**
					 * New code ends here
					 */
					// Application_Utils.validateReportGeneration(driver, i);

					// Application_Utils.excelToWrite(config.get("Report.OutPut.path"),sheetName,"JobNumber",
					// getJobNumber(), i);
					String endTimeIs = Formatter.getTimeStamp();

					System.out.println("Execution Time taken for \""
							+ sheetName + "\" report for iteration " + i
							+ " is "
							+ Formatter.getTimeLapsed(startTimeIs, endTimeIs)
							+ " minute(s)\n");
					driver.findElement(By.cssSelector("div.x-tool-close"))
							.click();

					wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
							.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
					driver.findElement(
							By.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))
							.click();
					Thread.sleep(5000);
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
