package com.test.ci.automation.or.non_network;

public class PlacementScreen {
	
	
	public static final String PLACEMENTREPORT = "linktext=Placement Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANCLASS = "xpath=//span[text()='Plan Class']/following::input[contains(@class,'x-form-text x-form-field')]";
	


}
