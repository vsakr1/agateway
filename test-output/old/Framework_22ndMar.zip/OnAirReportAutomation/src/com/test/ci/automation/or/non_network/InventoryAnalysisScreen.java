package com.test.ci.automation.or.non_network;

public class InventoryAnalysisScreen {
	
	public static final String INVENTORYANALYSISREPORT = "linktext=Inventory Analysis Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String REPORTTYPE = "xpath =//span[text()='Report Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PERIOD = "xpath =//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYTYPE = "xpath =//span[text()='Day Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RELATIVITY = "xpath =//span[text()='Relativity']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SPOTDATA = "";
	public static final String PRIMARYCATEGORY = "xpath =//span[text()='Primary Category']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String COMMERCIALTYPEGROUP = "xpath =//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FORMATTING = "";
	public static final String VIEWBY = "xpath = //span[text()='View By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYGROUPBY = "xpath =//span[text()='Primary Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String BYTIME = "xpath =//span[text()='By Time']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String BYBREAKSTART = "xpath =//span[text()='By Break Start']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";
	
	

}
