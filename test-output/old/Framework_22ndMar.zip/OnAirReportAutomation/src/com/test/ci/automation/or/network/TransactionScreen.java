package com.test.ci.automation.or.network;

public class TransactionScreen {
	public static final String TRANSACTIONREPORT = "linkText=Transaction Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ACTIVITYDATEFROM = "xpath=//span[text()='Activity Date / From']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ACTIVITYDATETO = "xpath=//span[text()='Activity Date / To']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String OUTPUTTYPE = "xpath=//span[text()='Output Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
