package com.test.ci.automation.scripts;

import org.testng.annotations.Test;

import com.test.ci.automation.reports.network.AdvertiserLogReport;
import com.test.ci.automation.reports.network.ChuckReport;
import com.test.ci.automation.reports.network.CommercialFormatReport;
import com.test.ci.automation.reports.network.CommercialFormatUnitValueReport;
import com.test.ci.automation.reports.network.CommercialPositionReport;
import com.test.ci.automation.reports.network.DemoRatingsCompareReport;
import com.test.ci.automation.reports.network.NetworkSalesReport;
import com.test.ci.automation.reports.network.NoChargeReport;
import com.test.ci.automation.reports.network.PlanDetailReport;
import com.test.ci.automation.reports.network.PlanHistoryReport;
import com.test.ci.automation.reports.network.ProgramHistoryReport;
import com.test.ci.automation.reports.network.ProgramInventoryReport;
import com.test.ci.automation.reports.network.ProgramLineupReport;
import com.test.ci.automation.reports.network.PromoRatingsReport;
import com.test.ci.automation.reports.network.RevisionHistoryReport;
import com.test.ci.automation.reports.network.RunOfSchedule;
import com.test.ci.automation.reports.network.SalesAnalysisReport;
import com.test.ci.automation.reports.network.ValueofADURCPSReport;
import com.test.ci.automation.reports.non_network.AdSalesSelloutReport;
import com.test.ci.automation.reports.non_network.AdvertiserDistributionbySellingNameReport;
import com.test.ci.automation.reports.non_network.AdvertiserPodPositionReport;
import com.test.ci.automation.reports.non_network.ChangeNotice;
import com.test.ci.automation.reports.non_network.CopyInstructionsLastUserReport;
import com.test.ci.automation.reports.non_network.DaypartProjectionsReport;
import com.test.ci.automation.reports.non_network.EndCreditSqueezeReport;
import com.test.ci.automation.reports.non_network.Financial_Rev_Sum_Report;
import com.test.ci.automation.reports.non_network.Flowchart_Report;
import com.test.ci.automation.reports.non_network.IncompleteReconReport;
import com.test.ci.automation.reports.non_network.InventoryAnalysisReport;
import com.test.ci.automation.reports.non_network.InventoryValuationReport;
import com.test.ci.automation.reports.non_network.LogViewReport;
import com.test.ci.automation.reports.non_network.NewDollarsBookedReport;
import com.test.ci.automation.reports.non_network.OptionsReport;
import com.test.ci.automation.reports.non_network.OrderLetterReport;
import com.test.ci.automation.reports.non_network.PlacementReport;
import com.test.ci.automation.reports.non_network.PlanDollarChangesReport;
import com.test.ci.automation.reports.non_network.PlanStewardshipReport;
import com.test.ci.automation.reports.non_network.PlanningRevenue;
import com.test.ci.automation.reports.non_network.PromoSlottingAdvance;
import com.test.ci.automation.reports.non_network.PropertyStewardshipReport;
import com.test.ci.automation.reports.non_network.Proposal_Report;
import com.test.ci.automation.reports.non_network.RatecardComparisonReport;
import com.test.ci.automation.reports.non_network.RatecardHistoryReport;
import com.test.ci.automation.reports.non_network.Ratecard_Report;
import com.test.ci.automation.reports.non_network.SellingNameNotOnRCReport;
import com.test.ci.automation.reports.non_network.SellingNameRevenueAndRatingReport;
import com.test.ci.automation.reports.non_network.SellingNameRevenueReport;
import com.test.ci.automation.reports.non_network.SellingNameStewardshipReport;
import com.test.ci.automation.reports.non_network.SellingNameVerificationReport;
import com.test.ci.automation.reports.non_network.UnitAiringsDR;
import com.test.ci.automation.reports.non_network.UnitAiringsNational;

public class GenerateReportScript extends BaseScripts {
	@Test
	public void runReport() throws InterruptedException {
		System.out.println(config.get("reportName") + "report name");
		if (config.get("reportName").equalsIgnoreCase(
				"Commercial Format Report")
				|| config.get("reportName").equalsIgnoreCase("CFR")) {
			CommercialFormatReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Advertiser Log Report")
				|| config.get("reportName").equalsIgnoreCase("AlR")) {
			AdvertiserLogReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Chuck Report")
				|| config.get("reportName").equalsIgnoreCase("CR")) {
			ChuckReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Commercial Format Report (Unit Value)")
				|| config.get("reportName").equalsIgnoreCase("CFRUV")) {
			CommercialFormatUnitValueReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Commercial Position Report")
				|| config.get("reportName").equalsIgnoreCase("CPR")) {
			CommercialPositionReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Demo Ratings Compare Report")
				|| config.get("reportName").equalsIgnoreCase("DRCR")) {
			DemoRatingsCompareReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Network Sales Report")
				|| config.get("reportName").equalsIgnoreCase("NSR")) {
			NetworkSalesReport.runScript();
		} else if (config.get("reportName")
				.equalsIgnoreCase("No Charge Report")
				|| config.get("reportName").equalsIgnoreCase("NCR")) {
			NoChargeReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Plan Detail Report")
				|| config.get("reportName").equalsIgnoreCase("PDR")) {
			PlanDetailReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Plan History Report")
				|| config.get("reportName").equalsIgnoreCase("PHR")) {
			PlanHistoryReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Program History Report")
				|| config.get("reportName").equalsIgnoreCase("PRHR")) {
			ProgramHistoryReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Program Inventory Report")
				|| config.get("reportName").equalsIgnoreCase("PIR")) {
			ProgramInventoryReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Program Lineup Report")
				|| config.get("reportName").equalsIgnoreCase("PLR")) {
			ProgramLineupReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Promo Ratings Report")
				|| config.get("reportName").equalsIgnoreCase("PRR")) {
			PromoRatingsReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Revision History Report")
				|| config.get("reportName").equalsIgnoreCase("RHR")) {
			RevisionHistoryReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Run of Schedule Report")
				|| config.get("reportName").equalsIgnoreCase("ROSR")) {
			RunOfSchedule.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Sales Analysis Report")
				|| config.get("reportName").equalsIgnoreCase("SAR")) {
			SalesAnalysisReport.runScript();
		} else if (config.get("reportName").equalsIgnoreCase(
				"Value of ADU/RCPS Report")
				|| config.get("reportName").equalsIgnoreCase("VOAR")) {
			ValueofADURCPSReport.runScript();}

		//Non-Network Reports

		else if (config.get("reportName").equalsIgnoreCase(
				"Advertiser Distribution by Selling Name Report")
				|| config.get("reportName").equalsIgnoreCase("ADSNR")) {
			AdvertiserDistributionbySellingNameReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Ad Sales Sellout Report")
				|| config.get("reportName").equalsIgnoreCase("ASSR")) {
			AdSalesSelloutReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Advertiser Pod Position Report")
				|| config.get("reportName").equalsIgnoreCase("APPR")) {
			AdvertiserPodPositionReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Change Notice")
				|| config.get("reportName").equalsIgnoreCase("CR")) {
			ChangeNotice.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Copy Instructions Last User Report")
				|| config.get("reportName").equalsIgnoreCase("CILUR")) {
			CopyInstructionsLastUserReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Daypart Projections Report")
				|| config.get("reportName").equalsIgnoreCase("DPR")) {
			DaypartProjectionsReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"End Credit Squeeze Report")
				|| config.get("reportName").equalsIgnoreCase("ECSR")) {
			EndCreditSqueezeReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Financial Revenue Summary Report")
				|| config.get("reportName").equalsIgnoreCase("FRSR")) {
			Financial_Rev_Sum_Report.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Flowchart Report")
				|| config.get("reportName").equalsIgnoreCase("FR")) {
			Flowchart_Report.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Incomplete Recon Report")
				|| config.get("reportName").equalsIgnoreCase("IRR")) {
			IncompleteReconReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Inventory Analysis Report")
				|| config.get("reportName").equalsIgnoreCase("IAR")) {
			InventoryAnalysisReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Inventory Valuation Report")
				|| config.get("reportName").equalsIgnoreCase("IVR")) {
			InventoryValuationReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Log View Report")
				|| config.get("reportName").equalsIgnoreCase("LVR")) {
			LogViewReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"New Dollars Booked Report")
				|| config.get("reportName").equalsIgnoreCase("NDBR")) {
			NewDollarsBookedReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Options Report")
				|| config.get("reportName").equalsIgnoreCase("OR")) {
			OptionsReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Order Letter Report")
				|| config.get("reportName").equalsIgnoreCase("OLR")) {
			OrderLetterReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Order Letter Report")
				|| config.get("reportName").equalsIgnoreCase("OLR")) {
			OrderLetterReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Placement Report")
				|| config.get("reportName").equalsIgnoreCase("PR")) {
			PlacementReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Plan Dollar Changes Report")
				|| config.get("reportName").equalsIgnoreCase("PDCR")) {
			PlanDollarChangesReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Planning Revenue Report")
				|| config.get("reportName").equalsIgnoreCase("PR")) {
			PlanningRevenue.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Plan Stewardship Report")
				|| config.get("reportName").equalsIgnoreCase("PSR")) {
			PlanStewardshipReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Promo Slotting Advance Report")
				|| config.get("reportName").equalsIgnoreCase("PSAR")) {
			PromoSlottingAdvance.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Property Stewardship Report")
				|| config.get("reportName").equalsIgnoreCase("PSR")) {
			PropertyStewardshipReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Proposal Report")
				|| config.get("reportName").equalsIgnoreCase("PR")) {
			Proposal_Report.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Ratecard Report")
				|| config.get("reportName").equalsIgnoreCase("RR")) {
			Ratecard_Report.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Ratecard Comparison Report")
				|| config.get("reportName").equalsIgnoreCase("RCR")) {
			RatecardComparisonReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Ratecard History Report")
				|| config.get("reportName").equalsIgnoreCase("RHR")) {
			RatecardHistoryReport.runScript();}	
		else if (config.get("reportName").equalsIgnoreCase(
				"Selling Name Not On RC Report")
				|| config.get("reportName").equalsIgnoreCase("SNNORCR")) {
			SellingNameNotOnRCReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Selling Name Revenue And Rating Report")
				|| config.get("reportName").equalsIgnoreCase("SNRARR")) {
			SellingNameRevenueAndRatingReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Selling Name Revenue Report")
				|| config.get("reportName").equalsIgnoreCase("SNRR")) {
			SellingNameRevenueReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Selling Name Stewardship Report")
				|| config.get("reportName").equalsIgnoreCase("SNSR")) {
			SellingNameStewardshipReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Selling Name Verification Report")
				|| config.get("reportName").equalsIgnoreCase("SNVR")) {
			SellingNameVerificationReport.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Unit Airing - DR Report")
				|| config.get("reportName").equalsIgnoreCase("UADRR")) {
			UnitAiringsDR.runScript();}
		else if (config.get("reportName").equalsIgnoreCase(
				"Unit Airing - National Report")
				|| config.get("reportName").equalsIgnoreCase("UANR")) {
			UnitAiringsNational.runScript();}
	}
}
