package com.test.ci.automation.reports.non_network;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.AdvertiserPodPositionScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class AdvertiserPodPositionReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException, IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		String[] tabs={"General"};
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {


			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber,"RunMode", i).equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("No")) 
				{
				} 
				else 
				{
					try {
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());
						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Advertiser Pod Position Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Advertiser Pod Position Report"))));
						driver.findElement(By.linkText("Advertiser Pod Position Report")).click();
						System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
						Thread.sleep(2000);
						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						actionDriver(Link, AdvertiserPodPositionScreen.CLEARFORM, "Click", "Clear Form", "Landing Page");


						// General tab
						driver.findElement(By.linkText(""+tabs[0]+"")).click();		
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i))))
							Log.error("Property is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "property", i) );

						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i));
						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i))))
							Log.error("Start Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i) );

						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i));
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i))))
							Log.error("End Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i) );

						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber, "advertiser", i),"Advertiser");	
						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber, "commercialtype", i),"Commercial Type");

						exportReport("Formatted Excel");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}