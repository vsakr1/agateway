package com.test.ci.automation.utils;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PDF_Excel_Compr {
	public static String excelComprFilePath;


	public static void main(String[] args)
	{	
		try{
			String reportName[]={"ORDERLETTER"};
			//"SALESANALYSIS",C:\Users\206447340\Desktop\New folder
			//\\USAOANVNP014\ci_archive\Automation\Proposal\T5-prod-post-run
			//String env1 ="////C://Users//206423258//Desktop//MondayTest//759//prerun";
			//String env2 ="////C://Users//206423258//Desktop//MondayTest//760";
			String env1 ="////C://Users//206447340//Desktop//OrderLetter_Prod-Post-run_9thFeb";
			String env2 ="////C://Users//206447340//Desktop//OrderLetter_Prod-Pre-run_8thFeb";
			String outputPath="////C://Users//206447340//Desktop//";

			for(int i =0; i < reportName.length; i++)
			{
				String pdfResultFile=outputPath+reportName[i]+".xlsx";
				String fileName="", fileName2="";
				int count=0, count2=0, loop1=0, loop2=0;
				Boolean compare=true;
				Boolean pdfReport=false;

				excelComprFilePath = pdfResultFile;
				PDFCompr_Test.setFilePath(excelComprFilePath);

				//Copying the required reports from an environment to required path 
				File dirSource = new File(env1);		
				for (File file : dirSource.listFiles()) {
					//Temporarily renaming the file in format below
					
					if(file.getName().contains(reportName[i]) )
					{
						count++;
						{
							if(count==1){
								File outputFolderNonNetwork = new File(outputPath+reportName[i]+"_Env1");
								if (!outputFolderNonNetwork.exists()) {
									if (outputFolderNonNetwork.mkdir())
										System.out.println(reportName[i]+"_Env1"+" Directory is created!");
									else 
										System.out.println("Failed to create"+ reportName[i]+"_Env1"+"  directory!");
								}
								//Creating a excel file for comparison only for file with .pdf extension
								if (file.getName().endsWith((".pdf"))) {
									try
									{
										//Creating a workbook for writing the comparison results
										pdfReport=true;
										XSSFWorkbook wb = new XSSFWorkbook();
										XSSFSheet sheet = wb.createSheet("Comparison") ;
										FileOutputStream fileOut = new FileOutputStream(pdfResultFile);
										wb.write(fileOut);
										fileOut.flush();
										fileOut.close();
									}
									catch (Exception e)
									{
										System.out.println(e.getMessage());
									}
								}
							}
						}
						String testCaseFolderOutput =outputPath+reportName[i]+"_Env1".concat("//");
						File dest = new File(testCaseFolderOutput+file.getName());
						FileUtils.copyFile(file, dest);
					}
				}

				//Copying the required reports from an environment to required path 
				File dirSource2 = new File(env2);		
				for (File file2 : dirSource2.listFiles()) {
					if(file2.getName().contains(reportName[i]) )
					{
						count2++;
						{
							if(count2==1){
								File outputFolderNonNetwork = new File(outputPath+reportName[i]+"_Env2");
								if (!outputFolderNonNetwork.exists()) {
									if (outputFolderNonNetwork.mkdir())
										System.out.println(reportName[i]+"_Env2"+" Directory is created!");
									else 
										System.out.println("Failed to create"+ reportName[i]+"_Env2"+"  directory!");
								}
							}
						}
						String testCaseFolderOutput =outputPath+reportName[i]+"_Env2".concat("//");
						File dest = new File(testCaseFolderOutput+file2.getName());
						FileUtils.copyFile(file2, dest);
					}
				}
				File dirSource3 = new File(outputPath+reportName[i]+"_Env1");		
				File dirSource4 = new File(outputPath+reportName[i]+"_Env2");		
				
				if(dirSource3.listFiles().length != dirSource4.listFiles().length)
				{
					System.out.println("File count is different in both the environments");
				}

				else
				{
					for (File file : dirSource3.listFiles()) 
					{
						loop1++;
						fileName = file.getName();
						if(fileName.contains(".pdf"))
						fileName = fileName.trim().replaceAll("(\\w{9}\\_\\d{6}\\_)|(\\_\\d+\\.(pdf))", "").trim();
						else
						{fileName = fileName.trim().replaceAll("(\\w{9}\\_\\d{6}\\_)|(\\_\\d+\\.(xls))", "").trim();}
						loop2=0;
						for (File file1 : dirSource4.listFiles()) 
						{
							loop2++;
							fileName2 = file1.getName();
							if(fileName2.contains(".pdf"))
							fileName2 = fileName2.trim().replaceAll("(\\w{9}\\_\\d{6}\\_)|(\\_\\d+\\.(pdf))", "").trim();
							else
							{fileName2 = fileName.trim().replaceAll("(\\w{9}\\_\\d{6}\\_)|(\\_\\d+\\.(xls))", "").trim();}
							if(fileName.equals(fileName2))
							{
								loop2=0;
								break;
							}
							if(loop2==dirSource3.listFiles().length && !(fileName.equals(fileName2)))
							{
								System.out.println("Not Same File 1 & File2 for RowNumber="+fileName+" "+fileName2+ " "+loop1);
								compare=false;
								
							}
						}
					}

					if(compare && pdfReport)
					{
						PDFCompr_Test.PDF(outputPath+reportName[i]+"_Env1".concat("//"),outputPath+reportName[i]+"_Env2".concat("//"),pdfResultFile);		
					}
					else if(compare && pdfReport==false)
					{
						try 
						{
							String vbScript="wscript "+outputPath.substring(4)+"findFileAndCompare.vbs";
							String parms = vbScript+" "+env1.substring(4)+" "+env2.substring(4);
							Runtime.getRuntime().exec(parms);
						}
						catch(Exception e ) {
							System.out.println(e.getMessage());}
					}
				}
			}
			System.out.println("Execution is completed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
