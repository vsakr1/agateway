package com.test.ci.automation.or.non_network;

public class OrderLetterScreen {
	
	public static final String ORDERLETTER = "linktext=Order Letter";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String SEARCHPLANS ="xpath =//span[text()='Search Plans']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CC = "xpath =//span[text()='CC']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String AGENCYCONTACT = "xpath=//span[text()='Agency Contact']/following::input[contains(@class,'x-form-text x-form-field')]";
	
}
