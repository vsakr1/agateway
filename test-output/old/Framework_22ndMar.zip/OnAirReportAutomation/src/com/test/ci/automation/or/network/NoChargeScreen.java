package com.test.ci.automation.or.network;

public class NoChargeScreen {
	public static final String NOCHARGEREPORT = "linkText=No Charge Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANTODATETHROUGH = "xpath=//span[text()='Plan to Date Through']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ALTERNATEDEMO = "xpath=//span[text()='Alternate Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANUNITDETAIL = "xpath=//span[contains(text(),'Plan')]/../../div/div/a";
	public static final String SELLINGNAMESUMMARY = "xpath=//span[text()='Selling Name Summary']/following::div[contains(@class,'x-form-invalid-icon')]";
	public static final String DEMOSUMMARY = "xpath=//span[text()='Demo Summary']/following::div[contains(@class,'x-form-invalid-icon')]";
	public static final String PLAN = "xpath=//span[contains(text(),'Plan')]/../../div/div/a";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
