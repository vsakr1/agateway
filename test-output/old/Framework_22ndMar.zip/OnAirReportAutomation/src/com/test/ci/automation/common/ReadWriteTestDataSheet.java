package com.test.ci.automation.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sun.jna.StringArray;
import com.test.ci.automation.scripts.BaseScripts;

public class ReadWriteTestDataSheet extends BaseScripts {
	public static FileOutputStream fileOut;
	public static FileInputStream fileInPut;

	public static void copyFile(File sourceFile, File destFile)
			throws IOException {
		// TODO Auto-generated method stub

		if (!destFile.exists()) {
			destFile.createNewFile();
		}
		FileInputStream fIn = null;
		FileOutputStream fOut = null;
		FileChannel source = null;
		FileChannel destination = null;
		try {
			fIn = new FileInputStream(sourceFile);
			source = fIn.getChannel();
			fOut = new FileOutputStream(destFile);
			destination = fOut.getChannel();
			long transfered = 0;
			long bytes = source.size();
			while (transfered < bytes) {
				transfered += destination
						.transferFrom(source, 0, source.size());
				destination.position(transfered);
			}
		} finally {
			if (source != null) {
				source.close();
			} else if (fIn != null) {
				fIn.close();
			}
			if (destination != null) {
				destination.close();
			} else if (fOut != null) {
				fOut.close();
			}
		}
	}

	public static void createExcelFile(String outpath, String fileName,
			String sheetName) {
		String filenamePath = outpath + "\\" + fileName;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet(sheetName);

		XSSFRow rowhead = sheet.createRow((short) 0);
		rowhead.createCell(0).setCellValue("Iteration Number");
		rowhead.createCell(1).setCellValue("Job Number");
		rowhead.createCell(2).setCellValue("Report Name");
		rowhead.createCell(3).setCellValue("TimeStamp");

		XSSFRow row = sheet.createRow((short) 1);
		row.createCell(0).setCellValue("1");
		row.createCell(1).setCellValue("Sankumarsingh");
		row.createCell(2).setCellValue("India");
		row.createCell(3).setCellValue("sankumarsingh@gmail.com");
		System.out.println(filenamePath);
		try {
			FileOutputStream fileOut = new FileOutputStream(filenamePath);
			workbook.write(fileOut);
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Your excel file has been generated!");

	}

	public static void readXLSFile(String xlsPath) throws IOException {
		InputStream ExcelFileToRead = new FileInputStream(xlsPath);
		HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

		HSSFSheet sheet = wb.getSheetAt(0);
		HSSFRow row;
		HSSFCell cell;

		Iterator rows = sheet.rowIterator();

		while (rows.hasNext()) {
			row = (HSSFRow) rows.next();
			Iterator cells = row.cellIterator();

			while (cells.hasNext()) {
				cell = (HSSFCell) cells.next();

				if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
					System.out.print(cell.getStringCellValue() + " ");
				} else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
					System.out.print(cell.getNumericCellValue() + " ");
				} else {
					// U Can Handel Boolean, Formula, Errors
				}
			}
			System.out.println();
		}

	}

	public static void writeXLSXFile() throws IOException {

		String excelFileName = "C:/Test.xlsx";// name of excel file

		String sheetName = "Sheet1";// name of sheet

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet(sheetName);

		// iterating r number of rows
		for (int r = 0; r < 5; r++) {
			XSSFRow row = sheet.createRow(r);

			// iterating c number of columns
			for (int c = 0; c < 5; c++) {
				XSSFCell cell = row.createCell(c);

				cell.setCellValue("Cell " + r + " " + c);
			}
		}

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static void writeXLSFile(String xlsPath) {
		try {
			String excelFileName = xlsPath;// name of excel file

			String sheetName = "Sheet1";// name of sheet

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet(sheetName);

			// iterating r number of rows
			for (int r = 0; r < 5; r++) {
				HSSFRow row = sheet.createRow(r);

				// iterating c number of columns
				for (int c = 0; c < 5; c++) {
					HSSFCell cell = row.createCell(c);

					cell.setCellValue("Cell " + r + " " + c);
				}
			}

			fileOut = new FileOutputStream(excelFileName);

			// write this workbook to an Outputstream.
			wb.write(fileOut);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				fileOut.flush();
				fileOut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void readXLSXFile(String xlsxPath) throws IOException {
		InputStream ExcelFileToRead = new FileInputStream(xlsxPath);
		XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);

		XSSFWorkbook test = new XSSFWorkbook();

		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row;
		XSSFCell cell;
		Iterator rows = sheet.rowIterator();

		while (rows.hasNext()) {
			row = (XSSFRow) rows.next();
			Iterator cells = row.cellIterator();
			while (cells.hasNext()) {
				cell = (XSSFCell) cells.next();

				if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
					System.out.print(cell.getStringCellValue() + " ");
				} else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
					System.out.print(cell.getNumericCellValue() + " ");
				} else {
					// U Can Handel Boolean, Formula, Errors
				}
			}
			System.out.println();
		}

	}

	public static void updateXLSXCell(String xlsxPath, String sheetName,
			String colomnName, int rowNumber, String cellValue)
			throws IOException {
		// String header[] = { "87899" };
		int rowIndex = rowNumber;
		String excelFileName = xlsxPath;// name of excel file

		// String sheetName = "commercialformat";// name of sheet
		InputStream inp = new FileInputStream(excelFileName);
		XSSFWorkbook wb = new XSSFWorkbook(inp);
		XSSFSheet sheet = wb.getSheet(sheetName);
		// iterating r number of rows

		for (int j = 0; j < wb.getSheetAt(0).getRow(0).getLastCellNum(); j++) {

			if (wb.getSheetAt(0).getRow(0).getCell(j).getStringCellValue()
					.equalsIgnoreCase(colomnName)) {

				// for (int i = 0; i < header.length; i++) {
				Row row = null;
				if (j == 0) {
					row = sheet.createRow(rowIndex++);
				} else {
					row = sheet.getRow(rowIndex++);
				}
				Cell cell0 = row.createCell(j);
				cell0.setCellValue(cellValue.trim());
				// Comment comment = drawing.createCellComment(anchor);
				// RichTextString str0 =
				// factory.createRichTextString(excelText(excelSheetCount("changenotice_sql"),
				// hdrColumn, r));
				// comment.setString(str0);
				// cell0.setCellComment(comment);
				// }
			}

		}
		// for (int r = 0; r < 5; r++) {
		// XSSFRow row = sheet.createRow(r);
		//
		// // iterating c number of columns
		// for (int c = 0; c < 5; c++) {
		// XSSFCell cell = row.createCell(c);
		//
		// cell.setCellValue("Cell " + r + " " + c);
		// }
		// }

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static void updateXLSXColomn(String xlsxPath, String sheetName,
			String colomnName, String[] cellValue) throws IOException {
		String listOfColValues[] = cellValue;
		int rowIndex = 1;
		String excelFileName = xlsxPath;// name of excel file

		// String sheetName =sheetName;// name of sheet
		InputStream inp = new FileInputStream(excelFileName);
		XSSFWorkbook wb = new XSSFWorkbook(inp);
		XSSFSheet sheet = wb.getSheet(sheetName);
		// iterating r number of rows

		for (int j = 0; j < wb.getSheetAt(0).getRow(0).getLastCellNum(); j++) {

			if (wb.getSheetAt(0).getRow(0).getCell(j).getStringCellValue()
					.equalsIgnoreCase(colomnName)) {

				for (int i = 0; i < listOfColValues.length; i++) {
					Row row = null;
					if (j == 0) {
						row = sheet.createRow(rowIndex++);
					} else {
						row = sheet.getRow(rowIndex++);
					}
					Cell cell0 = row.createCell(j);
					cell0.setCellValue(listOfColValues[i].trim());
					// Comment comment = drawing.createCellComment(anchor);
					// RichTextString str0 =
					// factory.createRichTextString(excelText(excelSheetCount("changenotice_sql"),
					// hdrColumn, r));
					// comment.setString(str0);
					// cell0.setCellComment(comment);
				}
			}

		}
		// for (int r = 0; r < 5; r++) {
		// XSSFRow row = sheet.createRow(r);
		//
		// // iterating c number of columns
		// for (int c = 0; c < 5; c++) {
		// XSSFCell cell = row.createCell(c);
		//
		// cell.setCellValue("Cell " + r + " " + c);
		// }
		// }

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static void updateXLSXFile(String xlsxPath, int rowNum)
			throws IOException {

		String excelFileName = xlsxPath;// name of excel file

		String sheetName = config.get("TestData.sheetName");// name of sheet

		XSSFWorkbook wb = new XSSFWorkbook(excelFileName);
		XSSFSheet sheet = wb.getSheet(sheetName);

		System.out.println(sheet.getPhysicalNumberOfRows()
				+ "   jhyuhijhjkjijkjjkj");
		Iterator rows = sheet.rowIterator();
		System.out.println(sheet.rowIterator().next()
				.getPhysicalNumberOfCells()
				+ "hghuhjhhjg");

		// System.out.println(wb.getSheet(sheetName).getPhysicalNumberOfRows());

		// int noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
		// System.out.println(noOfColumns);

		// // iterating r number of rows
		// for (int r = 0; r < 5; r++) {
		// XSSFRow row = sheet.createRow(r);
		//
		// // iterating c number of columns
		// for (int c = 0; c < 5; c++) {
		// XSSFCell cell = row.createCell(c);
		//
		// cell.setCellValue("Cell " + r + " " + c);
		// }
		// }
		//
		// FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		// wb.write(fileOut);
		// fileOut.flush();
		// fileOut.close();
	}

	public static int excelRowCount(int workSheetNumber) {
		try {
			FileInputStream file = new FileInputStream(new File(
					GlobalVariables.testDataFilePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(workSheetNumber);
			file.close();

			return sheet.getLastRowNum() + 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// e.printStackTrace();

		int result = 0;
		return result;
	}

	public static int excelRowCount(String workSheetName) {

		try {
			fileInPut = new FileInputStream(new File(
					GlobalVariables.testDataFilePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(fileInPut);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheet(workSheetName);

			return sheet.getPhysicalNumberOfRows();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				fileInPut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// e.printStackTrace();

		int result = 0;
		return result;
	}

	public static int excelSheetCount(String sheetName) {
		try {
			fileInPut = new FileInputStream(new File(
					GlobalVariables.testDataFilePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(fileInPut);

			int workSheetNum = 0;
			sheetName = sheetName.replaceAll("(^\\s*|\\s*$)", "");
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				// System.out.println(workbook.getSheetName(i));
				if (workbook.getSheetName(i).compareToIgnoreCase(sheetName) == 0) {
					workSheetNum = i;
					break;
				}
			}
			return workSheetNum;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				fileInPut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// e.printStackTrace();

		int result = 0;
		return result;
	}

	public static String excelText(int workSheetNumber, String columnName,
			int rowId) {
		try {
			String result = null;
			fileInPut = new FileInputStream(new File(
					GlobalVariables.testDataFilePath));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(fileInPut);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(workSheetNumber);
			Row row = sheet.getRow(0);

			String str1 = columnName;
			int columnNum = 0;
			for (int x = 0; x < row.getLastCellNum(); x++) {
				if ((str1.compareToIgnoreCase(row.getCell(x)
						.getStringCellValue())) == 0) {
					columnNum = x;
					break;
				}
			}
			row = sheet.getRow(rowId);
			Cell cell = row.getCell(columnNum);
			cell = row.getCell(columnNum);
			if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
				// This cell is empty
				result = "";
			} else {
				// This cell has data in it
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					result = Integer.toString((int) cell.getNumericCellValue());
					break;
				case Cell.CELL_TYPE_STRING:
					result = cell.getStringCellValue();
					break;
				}
			}

			result = result.replaceAll("(^\\s*|\\s*$)", "");
			return result;
		} catch (Exception e) {
			System.out.println(e.getMessage());

		} finally {
			try {
				fileInPut.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return columnName;
	}

	public static void main(String[] args) throws IOException {

		// writeXLSFile();
		// readXLSFile();
		//
		// writeXLSXFile();
		// readXLSXFile();

		// FileInputStream fsIP= new FileInputStream(new
		// File("C:\\dev\\log\\commercialformat.xlsx")); //Read the spreadsheet
		// that needs to be updated
		//
		// XSSFWorkbook wb = new XSSFWorkbook(fsIP); //Access the workbook
		//
		// XSSFSheet worksheet = wb.getSheetAt(0); //Access the worksheet, so
		// that we can update / modify it.
		//
		// XSSFCell cell = null; // declare a Cell object
		//
		// cell = worksheet.getRow(2).getCell(8); // Access the second cell in
		// second row to update the value
		//
		// cell.setCellValue("OverRide Last Name"); // Get current cell value
		// value and overwrite the value
		//
		// fsIP.close(); //Close the InputStream
		//
		// FileOutputStream output_file =new FileOutputStream(new
		// File("C:\\dev\\log\\commercialformat.xlsx")); //Open FileOutputStream
		// to write updates
		//
		// wb.write(output_file); //write changes
		//
		// output_file.close(); //close the stream

		// createExcelFile("c:\\dev\\log\\jagdish", "jamesBond.xlsx",
		// "sjsjskj");
		// readXLSXFile("C:\\dev\\log\\commercialformat.xlsx");
		// readXLSXFile("C:\\dev\\log\\commercialformat.xlsx");
		// String[] a = {"one","two","three","four"};
		// ArrayList<String> job =new ArrayList<String>();
		// job.add("djhdjdj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// job.add("djhdjdhj");
		// System.out.println(job.isEmpty() + "djdhjdhdjh");
		// String[] b = job.toArray(new String[job.size()]);
		// System.out.println(b.length);
		// updateXLSXCell("C:\\dev\\log\\commercialformat1.xlsx", "status", 7,
		// "pass done jaggu");
		// updateXLSXColomn("C:\\dev\\log\\commercialformat1.xlsx",
		// "commercialformat","status",
		// b);
//		System.out.println(excelRowCount(0));
//		;
//		System.out.println(excelRowCount("commercialformat"));
//		;

	}

}