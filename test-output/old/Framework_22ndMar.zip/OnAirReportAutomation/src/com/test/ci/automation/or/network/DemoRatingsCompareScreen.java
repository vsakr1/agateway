package com.test.ci.automation.or.network;

public class DemoRatingsCompareScreen {
	public static final String DEMORATINGSCOMPAREREPORT = "linkText=Demo Ratings Compare Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath=//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATECARD = "xpath=//span[text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAMS = "xpath=//span[text()='Rating Streams']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SELLINGNAMESET = "xpath=//span[text()='Selling Name Set']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SUMMARYDEMO = "xpath=//span[text()='Summary Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SUMMARYCPM = "xpath=//span[text()='Summary CPM ($)']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTOPDF = "xpath=//button[text()='Export to PDF']";
		

}
