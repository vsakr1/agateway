package com.test.ci.automation.reports.non_network;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.Financial_Rev_Sum_Screen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class Financial_Rev_Sum_Report extends BaseScripts {

	public static void main(String[] args) throws InterruptedException, IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		//Tab names which come across in the work flow 
		String[] tabs={"General","Plan Data","Spot Data","Formatting"};
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {

			
			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {
				
				if (ReadWriteTestDataSheet.excelText(sheetNumber,"RunMode", i).equalsIgnoreCase("N")
						|| ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("No")) 
				{
				} 
				else 
				{
					try {
						String startTimeIs = Formatter.getTimeStamp();
						Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());
						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Finance Revenue Summary Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Finance Revenue Summary Report"))));
						driver.findElement(By.linkText("Finance Revenue Summary Report")).click();
						System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
						Thread.sleep(5000);
						// Clear form
						/*wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						actionDriver(Link, Financial_Rev_Sum_Screen.CLEARFORM, "Click", "Clear Form", "Landing Page");*/
						driver.findElement(By
								.xpath("//*[contains(@class,'x-btn-text icon_clear')]")).click();
						Thread.sleep(5000);
						// General tab
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i))))
							Log.error("Property is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "property", i) );

						driver.findElement(By.xpath("//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "calendar", i));
						driver.findElement(By.xpath("//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Calendar']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "calendar", i))))
							Log.error("Calendar is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "calendar", i) );

						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i));
						driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i))))
							Log.error("Start Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "startdate", i) );

						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i));
						driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i))))
							Log.error("End Date is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "enddate", i) );


						// Plan data tab
						driver.findElement(By.linkText(""+tabs[1]+"")).click();
						//Application_Utils.waitWhileLoading(driver);
						Thread.sleep(3000);
						driver.findElement(By.xpath("//span[text()='Revenue Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "revenuetype", i));
						driver.findElement(By.xpath("//span[text()='Revenue Type']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Revenue Type']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "revenuetype", i))))
							Log.error("Revenue Type is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "revenuetype", i) );

						Application_Utils.moveToRight(driver,ReadWriteTestDataSheet.excelText(sheetNumber, "planclass", i),"Plan Class");


						Application_Utils.checkItemInSelect(driver,"Plan Status",ReadWriteTestDataSheet.excelText(sheetNumber, "planstatus", i));


						/*if (ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i)!=""){
							Application_Utils.checkItemInSelect(driver,"Plan Sub Status",ReadWriteTestDataSheet.excelText(sheetNumber, "plansubstatus", i));
						}*/
						// Spot data tab
						driver.findElement(By.linkText(""+tabs[2]+"")).click();
						Thread.sleep(3000);
						//Application_Utils.waitWhileLoading(driver);
						driver.findElement(By.xpath("//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
						
						Thread.sleep(1000);
						driver.findElement(By.xpath("//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "spotstatus", i));
						Thread.sleep(1000);
						driver.findElement(By.xpath("//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if(!(driver.findElement(By.xpath("//span[text()='Spot Status']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "spotstatus", i))))
							Log.error("Spot Status is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "spotstatus", i) );

						// Formatting tab
						driver.findElement(By.linkText(""+tabs[3]+"")).click();
						Application_Utils.checkItemInSelect(driver,"Optional Columns",ReadWriteTestDataSheet.excelText(sheetNumber, "optionalcolumns", i));
						if (ReadWriteTestDataSheet.excelText(sheetNumber, "optionalcolumns", i).equalsIgnoreCase("CPM")||ReadWriteTestDataSheet.excelText(sheetNumber, "optionalcolumns", i).equalsIgnoreCase("Select All"))
						{
							driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
							Thread.sleep(2000);
							driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "demo", i));
							Thread.sleep(2000);
							driver.findElement(By.xpath("//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
							Thread.sleep(2000);
						}
						driver.findElement(By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "daypartgrouping", i));
						driver.findElement(By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "daypartgrouping", i))))
							Log.error("Daypart Grouping is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "daypartgrouping", i) );
						
						driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "groupby", i));
						driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if(!(driver.findElement(By.xpath("//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "groupby", i))))
							Log.error("Group By is not "+ReadWriteTestDataSheet.excelText(sheetNumber, "groupby", i) );



						if (ReadWriteTestDataSheet.excelText(sheetNumber, "marketplacedetail", i).equalsIgnoreCase("Yes")){
							driver.findElement(By.xpath("//span[text()='Include Marketplace Detail']/following::a[contains(@class,'xcheckbox-off')]")).click();
							if(!driver.findElement(By.xpath("//span[text()='Include Marketplace Detail']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
								Log.error("Include Marketplace Detail checkbox is not checked");
						}

						if (ReadWriteTestDataSheet.excelText(sheetNumber, "commercialtypedetail", i).equalsIgnoreCase("Yes")){
							driver.findElement(By.xpath("//span[text()='Include Commercial Type Detail']/following::a[contains(@class,'xcheckbox-off')]")).click();
							if(!driver.findElement(By.xpath("//span[text()='Include Commercial Type Detail']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
								Log.error("Include Commercial Type Detail checkbox is not checked");
						}
						if (ReadWriteTestDataSheet.excelText(sheetNumber, "preemptibledetail", i).equalsIgnoreCase("Yes")){
							driver.findElement(By.xpath("//span[text()='Include Preemptible Detail']/following::a[contains(@class,'xcheckbox-off')]")).click();
							if(!driver.findElement(By.xpath("//span[text()='Include Preemptible Detail']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
								Log.error("Include Preemptible Detail checkbox is not checked");
						}

						

						clickOnFilterCriteriaCheckBox();	
						Thread.sleep(2000);
						if(!driver.findElement(By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]")).getAttribute("class").contains(" xcheckbox-on"))
							Log.error("Filter Criteria checkbox is not checked");
						exportReport("Formatted Excel");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""+ sheetName+ "\" report for iteration "+ i+ " is "
								+ Formatter.getTimeLapsed(startTimeIs, endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close")).click();
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}