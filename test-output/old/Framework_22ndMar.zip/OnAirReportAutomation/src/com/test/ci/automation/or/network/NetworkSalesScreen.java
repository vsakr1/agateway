package com.test.ci.automation.or.network;

public class NetworkSalesScreen {
	public static final String NETWORKSALESREPORT = "linkText=Network Sales Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DIVISION = "xpath=//span[text()='Division']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SUBDIVISION = "xpath=//span[text()='Sub Division']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath=//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTQUARTER = "xpath=//span[text()='Start Quarter']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDQUARTER = "xpath=//span[text()='End Quarter']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SORTBY = "xpath=//span[text()='Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DEMO = "xpath=//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
