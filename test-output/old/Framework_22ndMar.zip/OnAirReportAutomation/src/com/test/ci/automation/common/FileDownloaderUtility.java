package com.test.ci.automation.common;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Formatter;

public class FileDownloaderUtility extends BaseScripts {
	public static void main(String[] args) {
		// moveFiles("JobsId", 1);
		// System.out.println("C:\\dev\\log\\test\\test2");
		// System.out.println(getLatestFilefromDir("C:\\dev\\log\\test\\test2"));
		// waitUntilFileIsDownLoaded();
		// getLatestFilefromDir("C:\\dev\\log\\test\\test2");
		waitUntilFileIsDownLoaded("C:\\dev\\log\\test\\test2");
	}

	public static String moveFiles(String jobID, int i) {
		String copiedFilePath = "";
		try {
			File destination = null;
			// Thread.sleep(7000);
			// String patchFolder = "//" + patchFolderName;
			String targetFolder = config.get("targetFolder.path") + "\\"
					+ Formatter.getDate()+"\\"+config.get("reportName")+"\\"+config.get("runtype");
			// String defaultFolder = settings("downloadfolder");
			String defaultFolder = config.get("deafaultFolder.path");
			File dirSource = new File(defaultFolder);
			File dirTarget = new File(targetFolder);
			System.out.println(dirSource.getAbsolutePath()
					+ " this is the source folder");
			System.out.println(dirTarget.getAbsolutePath()
					+ " this the target filder");
			if (!dirTarget.exists()) {
				dirTarget.mkdirs();
				System.out
						.println(dirTarget.getAbsolutePath() + " is the path");
			}

			for (File file : dirSource.listFiles()) {

				if (file.getName().endsWith((".xls"))) {
					File source = new File(defaultFolder + "//"
							+ file.getName());
					Date creationDate = new Date(source.lastModified());
					DateFormat df = new SimpleDateFormat("ddMMMyyyy_HHmmss");// H:24
																				// hrs,
																				// h:
																				// 12hrs

					String fileName = file.getName();
					fileName = fileName.replaceAll("[^a-zA-z]", "");
					fileName = fileName.replace("xls", "");
					// System.out.println(defaultFolder+patchFolder+"//"+fileName+"_"+df.format(creationDate)+".xls");
					destination = new File(dirTarget + "//" + fileName + "_"
							+ df.format(creationDate) + "_" + jobID + "_" + i
							+ ".xls");
					// File destination = new
					// File(defaultFolder+patchFolder+"//"+fileName+"_"+patchFolderName+"_"+i+".xls");
					if (!destination.exists()) {
						source.renameTo(destination);
						System.out.println(destination.getAbsolutePath()
								+ " directory exist");
					}
				}

				if (file.getName().endsWith((".pdf"))) {
					File source = new File(defaultFolder + "//"
							+ file.getName());
					Date creationDate = new Date(source.lastModified());
					DateFormat df = new SimpleDateFormat("ddMMMyyyy_HHmmss");// H:24
																				// hrs,
																				// h:
																				// 12hrs

					String fileName = file.getName();
					fileName = fileName.replaceAll("[^a-zA-z]", "");
					fileName = fileName.replace("pdf", "");
					// System.out.println(defaultFolder+patchFolder+"//"+fileName+"_"+df.format(creationDate)+".xls");
					destination = new File(dirTarget + "//" + fileName + "_"
							+ df.format(creationDate) + "_" + jobID + "_" + i
							+ "_" + ".pdf");
					// File destination = new
					// File(defaultFolder+patchFolder+"//"+fileName+"_"+patchFolderName+"_"+i+".xls");
					if (!destination.exists()) {
						source.renameTo(destination);
						System.out.println(destination.getAbsolutePath());
					}
				}
			}
			copiedFilePath = destination.getAbsolutePath().toString();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return copiedFilePath;
	}

	public static void waitUntilFileIsDownLoaded(String dirPath) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy--HH.mm.ss");
		int counter = 0;
		int counterStage1 = 0;
		Date beforeFileDownLoad = null;
		Date fileModifiedTime = null;
		try {
			beforeFileDownLoad = sdf.parse(Formatter.getTimeStamp());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File dir = new File(dirPath);
		File[] files = null;
		files = dir.listFiles();
		if (files.length == 0) {
			do {
				files = dir.listFiles();
				System.out.println("file is : " + files.length);
				counterStage1++;
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (counterStage1 == 30) {
					break;
				}
				System.out
						.println("Inside no file loop. There no files available yet. Waiting for file to get download");
			} while (files.length == 0);
			System.out.println("Out of first statge ----> file download");

		}
		do {
			counter++;
			try {
				Thread.sleep(3000);
				System.out
						.println("We have the file available. Let get the downloaded file");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileModifiedTime = sdf.parse(getLatestFileTimeStamp(dirPath));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!fileModifiedTime.after(beforeFileDownLoad)) {
				System.out.println(" No file is not the latest");
			} else {
				System.out
						.println("yes file is lates so here it should be out of loop");
				String nameOfFile = getLatestFilefromDir(dirPath).getName();
				do {
					nameOfFile = getLatestFilefromDir(dirPath).getName();
					System.out
							.println(" file is still downloading and name is "
									+ nameOfFile);

					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (counter == 60) {
						break;

					}
					counter++;
				} while (nameOfFile.contains("crdownload"));
			}
			if (counter == 60) {
				break;

			}
		} while (!fileModifiedTime.after(beforeFileDownLoad));

		// String lastModifiedTime = getLatestFileTimeStamp(dirPath);
		// try {
		// fileModifiedTime = sdf.parse(lastModifiedTime);
		// } catch (ParseException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// if (beforeFileDownLoad.after(fileModifiedTime)) {
		// for (int i = 0; i < files.length; i++) {
		//
		// }
		// }
	}

	public static void deleteExistingFiles(String dirPath){
		File dir = new File(dirPath);
		File[] files = null;
		files = dir.listFiles();
		System.out.println(files.length);
		if (files.length == 0) {
			System.out.println("nooooo");
		} else {

			for (File f : files) {
				if (f.isFile() && f.exists()) {
					f.delete();
				} else {
					System.out
							.println("cant delete a file due to open or error");
				}
			}
		}

	}
	public static void waitUntilFileIsDownLoaded(String dirPath,
			String timeBeforFileDownload) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy--HH.mm.ss");
		int counter = 0;
		int counterStage1 = 0;
		Date beforeFileDownLoad = null;
		Date fileModifiedTime = null;
		try {
			beforeFileDownLoad = sdf.parse(timeBeforFileDownload);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File dir = new File(dirPath);
		File[] files = null;
		files = dir.listFiles();
		if (files.length == 0) {
			do {
				files = dir.listFiles();
				System.out.println("file is : " + files.length);
				counterStage1++;
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (counterStage1 == 30) {
					break;
				}
				System.out
						.println("Inside no file loop. There no files available yet. Waiting for file to get download");
			} while (files.length == 0);
			System.out.println("Out of first statge ----> file download");

		}
		do {
			counter++;
			try {
				Thread.sleep(3000);
				System.out
						.println("We have the file available. Let get the downloaded file");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileModifiedTime = sdf.parse(getLatestFileTimeStamp(dirPath));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!fileModifiedTime.after(beforeFileDownLoad)
					|| fileModifiedTime == beforeFileDownLoad) {
				System.out
						.println(" No file is not the latest before time is :"
								+ sdf.format(beforeFileDownLoad)
								+ " after time is "
								+ sdf.format(fileModifiedTime));
			} else {
				System.out
						.println("yes file is lates so here it should be out of loop");
				String nameOfFile = getLatestFilefromDir(dirPath).getName();
				do {
					nameOfFile = getLatestFilefromDir(dirPath).getName();
					System.out
							.println(" file is still downloading and name is "
									+ nameOfFile);
					System.out.println("File timings : "
							+ sdf.format(beforeFileDownLoad)
							+ " after time is " + sdf.format(fileModifiedTime));
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (counter == 60) {
						break;

					}
					counter++;
				} while (nameOfFile.contains("crdownload"));
			}
			if (counter == 60) {
				break;

			}
			System.out.println("File timings : "
					+ sdf.format(beforeFileDownLoad) + " after time is "
					+ sdf.format(fileModifiedTime));
		} while (!fileModifiedTime.after(beforeFileDownLoad)||fileModifiedTime==beforeFileDownLoad);

		// String lastModifiedTime = getLatestFileTimeStamp(dirPath);
		// try {
		// fileModifiedTime = sdf.parse(lastModifiedTime);
		// } catch (ParseException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// if (beforeFileDownLoad.after(fileModifiedTime)) {
		// for (int i = 0; i < files.length; i++) {
		//
		// }
		// }
	}

	private static String getLatestFileTimeStamp(String dirPath) {
		String lastTime = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"MM-dd-yyyy--HH.mm.ss");
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			System.out.println("There are no file ---> STAGE 1 failed");
			return null;
		}

		if (files.length == 1) {
			System.out
					.println("There is only one file available. Verify if it is latest");
			lastTime = dateFormat.format(files[0].lastModified());

			return lastTime;
		} else {
			File lastModifiedFile = files[0];
			for (int i = 1; i < files.length; i++) {
				if (lastModifiedFile.lastModified() < files[i].lastModified()) {
					lastModifiedFile = files[i];
					long timelast = lastModifiedFile.lastModified();
					dateFormat.format(timelast);
				}
			}
			System.out.println(lastModifiedFile
					+ " this is the file name which is modified");
			lastTime = dateFormat.format(lastModifiedFile.lastModified());
		}

		return lastTime;
	}

	private static File getLatestFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		System.out.println(dirPath);
		if (files == null || files.length == 0) {
			return null;
		}
		if (files.length == 1) {
			files[0].lastModified();
		}
		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
				long timelast = lastModifiedFile.lastModified();

				SimpleDateFormat dateFormat = new SimpleDateFormat(
						"MM-dd-yyyy--HH.mm.ss");
				dateFormat.format(timelast);
			}
		}
		return lastModifiedFile;
	}

	public static void waitUntilFileIsDownLoaded1() {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy--HH.mm.ss");
		int counter = 0;
		Date beforeFileDownLoad = null;
		Date fileModifiedTime = null;
		try {
			beforeFileDownLoad = sdf.parse("02-22-2016--22.06.21");
			System.out.println(Formatter.getTimeStamp() + " FIrst");
			Thread.sleep(100);
			fileModifiedTime = sdf.parse("02-22-2016--22.24.21");
			System.out.println(Formatter.getTimeStamp() + " second");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (fileModifiedTime.after(beforeFileDownLoad)) {
			System.out.println("yes it is inside");
		} else {
			System.out.println("noooo");
		}
	}
}
