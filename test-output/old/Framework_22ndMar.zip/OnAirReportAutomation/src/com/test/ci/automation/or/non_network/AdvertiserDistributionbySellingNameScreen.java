package com.test.ci.automation.or.non_network;

public class AdvertiserDistributionbySellingNameScreen {
	
	public static final String ADVERTISERDISTRIBUTIONBYSELLINGNAMEREPORT = "linkText =Advertiser Distribution by Selling Name Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PLANDATA = "";
	public static final String PLANCLASS = "xpath =//span[text()='planclass']/following::img[contains(@src,'none.gif')]";
	public static final String SPOTDATA = "";
	public static final String COMMERCIALTYPEGROUP = "xpath =//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SELLINGNAME = "";
	public static final String DAYPART = "xpath =//span[text()='daypart']/following::img[contains(@src,'none.gif')]";
	public static final String FORMATTING = "";
	public static final String FILTERCRITERIA = "xpath =//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";
	
	
	
	
}
