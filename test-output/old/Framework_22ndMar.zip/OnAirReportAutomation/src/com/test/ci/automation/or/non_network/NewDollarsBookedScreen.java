package com.test.ci.automation.or.non_network;

public class NewDollarsBookedScreen {
	
	public static final String NEWDOLLARSBOOKEDREPORT= "linktext=New Dollars Booked Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String GENERAL = "";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String CPMDISPLAY = "xpath =//span[text()='CPM Display']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SORTBY = "xpath =//span[text()='Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FILTERCRITERIA = "xpath =//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";

}
