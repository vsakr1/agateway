package com.test.ci.automation.or.non_network;

public class Flowchart_Screen {
	
	
	public static final String FLOWCHARTREPORT = "linktext=Flowchart Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PLANDATA = "";
	public static final String  SEARCHCOMBOFLOW = "id =searchcombo_flow";
	public static final String FILTERS_MEASURES = "";
	public static final String UETYPE = "xpath =//span[text()='UE Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FORMATTING = "";
	public static final String ADURCIMPRESSIONS = "xpath =//span[text()='ADU/RC Impressions']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath =//span[text()='Excel Formatted']";

}
