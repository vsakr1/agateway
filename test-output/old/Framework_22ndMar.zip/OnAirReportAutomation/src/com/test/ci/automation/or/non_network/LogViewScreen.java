package com.test.ci.automation.or.non_network;

public class LogViewScreen {
	

	public static final String ENDCREDITSQUEEZEREPORT = "linktext=End Credit Squeeze Report";
	public static final String CLEARFORM = "xpath =//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYTYPE = "xpath =//span[text()='Day Type']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SHOWSTATUS = "xpath = //span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DATE = "xpath =//span[text()='Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DISPLAYEDCOLUMNS = "xpath =//span[text()='Displayed Columns']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String FILTERCRITERIA = "xpath =//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox-off')]";
	public static final String EXPORTTO = "xpath =//button[text()='Export to']";
	public static final String EXCELUNFORMATTED = "xpath =//span[text()='Excel Unformatted']";
}
