package com.test.ci.automation.reports.non_network;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.test.ci.automation.common.ReadWriteTestDataSheet;
import com.test.ci.automation.or.non_network.AdSalesSelloutScreen;
import com.test.ci.automation.scripts.BaseScripts;
import com.test.ci.automation.utils.Application_Utils;
import com.test.ci.automation.utils.Formatter;

public class AdSalesSelloutReport extends BaseScripts {

	public static void main(String[] args) throws InterruptedException,
	IOException {
		runScript();
	}

	public static void runScript() throws InterruptedException {
		// Assigning the value for report name
		String sheetName = config.get("TestData.sheetName");
		String[] tabs = { "General", "Plan Data", "Spot Data", "Selling Name",
		"Formatting" };
		int sheetNumber = ReadWriteTestDataSheet.excelSheetCount(sheetName);
		try {
			// launchApplication(config.get("INTDEV"));
			// waitForWindowTitle("Dashboard");
			// WebDriverWait wait = new WebDriverWait(driver, 60);
			// wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Ad Sales Sellout Report"))));
			// wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Ad Sales Sellout Report"))));
			// driver.findElement(By.linkText("Ad Sales Sellout Report")).click();
			// System.out.println(((org.openqa.selenium.JavascriptExecutor)
			// driver).executeScript("return document.readyState"));
			// Thread.sleep(2000);

			for (int i = 1; i < ReadWriteTestDataSheet.excelRowCount(config.get("TestData.sheetName")); i = i + 1) {

				if (ReadWriteTestDataSheet.excelText(sheetNumber, "RunMode", i).equalsIgnoreCase("N")|| ReadWriteTestDataSheet.excelText(sheetNumber,
								"RunMode", i).equalsIgnoreCase("No")) {
				} else {
					/**
					 * Flow change code start here
					 */
					try {
						launchApplicationByEnvironment(config.get("ENV"));
						waitForWindowTitle("Dashboard");
						WebDriverWait wait = new WebDriverWait(driver, 60);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Ad Sales Sellout Report"))));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Ad Sales Sellout Report"))));
						driver.findElement(By.linkText("Ad Sales Sellout Report")).click();
						System.out.println(((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState"));
						Thread.sleep(2000);

						String startTimeIs = Formatter.getTimeStamp();
						// Application_Utils.getStartTime();
						Logger Log = Logger.getLogger(Log.class.getName());
						Thread.sleep(2000);
						// Clear form
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[contains(@class,'x-btn-text icon_clear')]"))));
						driver.findElement(By.xpath("//*[contains(@class,'x-btn-text icon_clear')]")).click();
						// actionDriver(Link, AdSalesSelloutScreen.CLEARFORM,
						// "Click", "Clear Form", "Landing Page");

						// General tab
						driver.findElement(By.linkText("" + tabs[0] + "")).click();
						Thread.sleep(2000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).clear();
						Thread.sleep(1000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));
						Thread.sleep(1000);
						driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if (!(driver.findElement(By.xpath("//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]")).getAttribute("value").equals(ReadWriteTestDataSheet.excelText(sheetNumber, "property", i))))
							Log.error("Property is not "+ ReadWriteTestDataSheet.excelText(sheetNumber, "property", i));

						driver.findElement(By.xpath("//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(ReadWriteTestDataSheet.excelText(sheetNumber, "period", i));
						driver.findElement(By.xpath("//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]")).sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Period']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "period", i))))
							Log.error("Period is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "period", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "startdate", i));
						driver.findElement(
								By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "startdate", i))))
							Log.error("Start Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "startdate", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "enddate", i));
						driver.findElement(
								By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "enddate", i))))
							Log.error("End Date is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "enddate", i));
						Thread.sleep(1100);

						// Plan data tab
						driver.findElement(By.linkText("" + tabs[1] + ""))
						.click();
						Thread.sleep(2000);
						Application_Utils.moveToRight(driver,
								ReadWriteTestDataSheet.excelText(sheetNumber,
										"planclass", i), "Plan Class");

						// Spot data tab
						driver.findElement(By.linkText("" + tabs[2] + ""))
						.click();
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.clear();
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.clear();
						// Thread.sleep(4000);

						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber,
												"commercialtypegroup", i));
						Thread.sleep(1000);
						driver.findElement(
								By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "commercialtypegroup", i))))
							Log.error("Commercial Type Group is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "commercialtypegroup",
											i));

						// Selling Name tab
						driver.findElement(By.linkText("" + tabs[3] + ""))
						.click();
						Thread.sleep(2000);
						Application_Utils.moveToRight(driver,
								ReadWriteTestDataSheet.excelText(sheetNumber,
										"daypart", i), "Daypart");

						// Formatting tab
						driver.findElement(By.linkText("" + tabs[4] + ""))
						.click();
						Thread.sleep(2000);
						if (ReadWriteTestDataSheet.excelText(sheetNumber,
								"choice", i).equals("Pressure")) {
							Application_Utils.moveToRight(driver,
									ReadWriteTestDataSheet.excelText(
											sheetNumber, "planstatus", i),
									"Pressure");
							Thread.sleep(1000);
							Application_Utils.checkItemInSelect(driver,
									"Pressure", ReadWriteTestDataSheet
									.excelText(sheetNumber, "pressure",
											i));
							if ((driver
									.findElement(
											By.xpath("//span[text()='Sold']/../../div/div/input[@type='text']"))
											.isEnabled() || driver
											.findElement(
													By.xpath("//span[text()='Other']/../../div/div/input[@type='text']"))
													.isEnabled()))
								Log.error("Either Sold or Other dropdown is enabled");
						} else if (ReadWriteTestDataSheet.excelText(
								sheetNumber, "choice", i).equals("Sold")) {
							Application_Utils.moveToRight(driver,
									ReadWriteTestDataSheet.excelText(
											sheetNumber, "planstatus", i),
									"Sold");
							Thread.sleep(1000);
							Application_Utils.checkItemInSelect(driver, "Sold",
									ReadWriteTestDataSheet.excelText(
											sheetNumber, "sold", i));
							if ((driver
									.findElement(
											By.xpath("//span[text()='Pressure']/../../div/div/input[@type='text']"))
											.isEnabled() || driver
											.findElement(
													By.xpath("//span[text()='Other']/../../div/div/input[@type='text']"))
													.isEnabled()))
								Log.error("Either Pressure or Other dropdown is enabled");
						} else if (ReadWriteTestDataSheet.excelText(
								sheetNumber, "choice", i).equals("Other")) {
							Application_Utils.moveToRight(driver,
									ReadWriteTestDataSheet.excelText(
											sheetNumber, "planstatus", i),
									"Other");
							Thread.sleep(1000);
							Application_Utils.checkItemInSelect(driver,
									"Other", ReadWriteTestDataSheet.excelText(
											sheetNumber, "other", i));
							if ((driver
									.findElement(
											By.xpath("//span[text()='Pressure']/../../div/div/input[@type='text']"))
											.isEnabled() || driver
											.findElement(
													By.xpath("//span[text()='Sold']/../../div/div/input[@type='text']"))
													.isEnabled()))
								Log.error("Either Pressure or Sold dropdown is enabled");
						}

						driver.findElement(
								By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartgrouping",
												i));
						driver.findElement(
								By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Daypart Grouping']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartgrouping", i))))
							Log.error("Daypart Grouping is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "daypartgrouping", i));

						driver.findElement(
								By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(
										ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartsummary",
												i));
						driver.findElement(
								By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
								.sendKeys(Keys.ENTER);
						if (!(driver
								.findElement(
										By.xpath("//span[text()='Daypart Summary']/following::input[contains(@class,'x-form-text x-form-field')]"))
										.getAttribute("value")
										.equals(ReadWriteTestDataSheet.excelText(
												sheetNumber, "daypartsummary", i))))
							Log.error("Daypart Summary is not "
									+ ReadWriteTestDataSheet.excelText(
											sheetNumber, "daypartsummary", i));

						clickOnFilterCriteriaCheckBox();
						Thread.sleep(2000);
						if (!driver
								.findElement(
										By.xpath("//span[text()='Filter Criteria']/following::a[contains(@class,'xcheckbox')]"))
										.getAttribute("class")
										.contains(" xcheckbox-on"))
							Log.error("Filter Criteria checkbox is not checked");
						Thread.sleep(5002);
						exportReport("Formatted Excel");
						String jobNumber = null;
						jobNumber = getJobNumber();
						JOBID.add(jobNumber);

						updateJobNumberToTestDataSheet(jobNumber, i);
						String endTimeIs = Formatter.getTimeStamp();
						System.out.println("Execution Time taken for \""
								+ sheetName
								+ "\" report for iteration "
								+ i
								+ " is "
								+ Formatter.getTimeLapsed(startTimeIs,
										endTimeIs) + " minute(s)\n");

						driver.findElement(By.cssSelector("div.x-tool-close"))
						.click();
						/**
						 * Flow change code move the catch and finally block here
						 */
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					} finally {
						driver.close();
						driver.quit();
					}
					/**
					 * End here
					 */
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			/**
			 * Comment this code in second finally block
			 */
			// driver.close();
			// driver.quit();
			exreport.endTest(exlogger);
		}
		exreport.flush();
	}
}