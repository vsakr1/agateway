package com.test.ci.automation.or.network;

public class PlanDetailScreen {
	public static final String PLANDETAILREPORT = "linkText=Plan Detail Report";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String SEARCHPLANS = "id=searchcombo_planDetail";
	public static final String GROUPBY = "xpath=//span[text()='Group By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String PRIMARYSORTBY = "xpath=//span[text()='Primary Sort By']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTO = "xpath=button[text()='Export to']";
	public static final String EXCELFORMATTED = "xpath=span[text()='Excel Formatted']";
}
