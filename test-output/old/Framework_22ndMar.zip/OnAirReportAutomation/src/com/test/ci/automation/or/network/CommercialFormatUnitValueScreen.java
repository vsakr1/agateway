package com.test.ci.automation.or.network;

public class CommercialFormatUnitValueScreen {
	public static final String COMMERCIALFORMATREPORTUNITVALUE = "linkText=Commercial Format Report (Unit Value)";
	public static final String CLEARFORM = "xpath=//*[contains(@class,'x-btn-text icon_clear')]";
	public static final String PROPERTY = "xpath=//span[text()='Property']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String COMMERCIALTYPEGROUP = "xpath=//span[text()='Commercial Type Group']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String SHOWSTATUS = "xpath=//span[text()='Show Status']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String DAYPART = "xpath=//span[text()='Daypart']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String STARTDATE = "xpath=//span[text()='Start Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String ENDDATE = "xpath=//span[text()='End Date']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATINGSTREAM = "xpath=//span[text()='Rating Stream']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String RATECARD = "xpath//span[text()='Ratecard']/following::input[contains(@class,'x-form-text x-form-field')]=";
	public static final String DEMO = "xpath=//span[text()='Demo']/following::input[contains(@class,'x-form-text x-form-field')]";
	public static final String EXPORTTOPDF = "xpath=//button[text()='Export to PDF']";
}
